function ResourceManager() {
    const trickleObjAPI = new TrickleObjectAPI();
    const RESOURCE_CONFIG_TYPE = 'resource-config';

    async function saveResourceConfig(productId, resourceType, config) {
        try {
            const configId = `${productId}-${resourceType}`;
            const configData = {
                productId,
                resourceType,
                config,
                lastUpdated: new Date().toISOString()
            };

            return await trickleObjAPI.createObject(RESOURCE_CONFIG_TYPE, configData);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getResourceConfig(productId, resourceType) {
        try {
            const response = await trickleObjAPI.listObjects(
                RESOURCE_CONFIG_TYPE,
                1,
                true,
                undefined
            );

            return response.items.find(item => 
                item.objectData.productId === productId && 
                item.objectData.resourceType === resourceType
            );
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function validateResourceConfig(resourceType, config) {
        try {
            const api = getResourceAPI(resourceType);
            return await api.validateCredentials(config);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function fetchResourceData(productId, resourceType) {
        try {
            const config = await getResourceConfig(productId, resourceType);
            if (!config) {
                throw new Error(`No configuration found for ${resourceType}`);
            }

            const api = getResourceAPI(resourceType);
            return await api.fetchData(config.objectData.config);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    function getResourceAPI(resourceType) {
        switch (resourceType) {
            case 'github':
                return GitHubAPI();
            case 'vercel':
                return VercelAPI();
            case 'analytics':
                return AnalyticsAPI();
            case 'monitoring':
                return MonitoringAPI();
            default:
                throw new Error(`Unknown resource type: ${resourceType}`);
        }
    }

    return {
        saveResourceConfig,
        getResourceConfig,
        validateResourceConfig,
        fetchResourceData
    };
}
