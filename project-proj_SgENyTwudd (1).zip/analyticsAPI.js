function AnalyticsAPI() {
    async function validateCredentials(config) {
        try {
            switch (config.provider) {
                case 'google-analytics':
                    return await validateGoogleAnalytics(config);
                case 'plausible':
                    return await validatePlausible(config);
                default:
                    throw new Error(`Unsupported analytics provider: ${config.provider}`);
            }
        } catch (error) {
            reportError(error);
            return false;
        }
    }

    async function fetchData(config) {
        try {
            switch (config.provider) {
                case 'google-analytics':
                    return await fetchGoogleAnalyticsData(config);
                case 'plausible':
                    return await fetchPlausibleData(config);
                default:
                    throw new Error(`Unsupported analytics provider: ${config.provider}`);
            }
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function validateGoogleAnalytics(config) {
        try {
            const response = await fetch(
                `https://www.googleapis.com/analytics/v3/management/accounts/~all/webproperties/~all/profiles`,
                {
                    headers: {
                        'Authorization': `Bearer ${config.token}`
                    }
                }
            );

            return response.ok;
        } catch (error) {
            reportError(error);
            return false;
        }
    }

    async function validatePlausible(config) {
        try {
            const response = await fetch(`https://plausible.io/api/v1/stats/realtime/visitors?site_id=${config.siteId}`, {
                headers: {
                    'Authorization': `Bearer ${config.token}`
                }
            });

            return response.ok;
        } catch (error) {
            reportError(error);
            return false;
        }
    }

    async function fetchGoogleAnalyticsData(config) {
        try {
            const response = await fetch(
                `https://www.googleapis.com/analytics/v3/data/ga?ids=ga:${config.viewId}&metrics=ga:users,ga:sessions,ga:pageviews&start-date=30daysAgo&end-date=today`,
                {
                    headers: {
                        'Authorization': `Bearer ${config.token}`
                    }
                }
            );

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            const data = await response.json();

            return {
                provider: 'google-analytics',
                metrics: {
                    users: parseInt(data.totalsForAllResults['ga:users']),
                    sessions: parseInt(data.totalsForAllResults['ga:sessions']),
                    pageviews: parseInt(data.totalsForAllResults['ga:pageviews'])
                }
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function fetchPlausibleData(config) {
        try {
            const response = await fetch(`https://plausible.io/api/v1/stats/aggregate?site_id=${config.siteId}&period=30d&metrics=visitors,pageviews,bounce_rate,visit_duration`, {
                headers: {
                    'Authorization': `Bearer ${config.token}`
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            const data = await response.json();

            return {
                provider: 'plausible',
                metrics: {
                    visitors: data.results.visitors.value,
                    pageviews: data.results.pageviews.value,
                    bounceRate: data.results.bounce_rate.value,
                    visitDuration: data.results.visit_duration.value
                }
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        validateCredentials,
        fetchData
    };
}
