function ProductOverviewCard({ product, onClick }) {
    const metrics = product.objectData.metrics;

    return (
        <div 
            data-name={`product-overview-${product.objectId}`}
            onClick={onClick}
            className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 rounded-xl p-6 hover:border-primary-500/50 transition-all duration-300 cursor-pointer group"
        >
            <CardHeader 
                name={product.objectData.name}
                domain={product.objectData.domain}
                githubUrl={product.objectData.githubUrl}
                status={metrics.status}
            />

            <MetricsSection 
                revenue={metrics.revenue}
                revenueTrend={metrics.revenueTrend}
                users={metrics.users}
                usersTrend={metrics.usersTrend}
            />

            <TechStack 
                hosting={product.objectData.hosting}
                database={product.objectData.database}
                auth={product.objectData.auth}
            />

            <StatusFooter 
                uptime={metrics.uptime}
                responseTime={metrics.responseTime}
            />
        </div>
    );
}

function CardHeader({ name, domain, githubUrl, status }) {
    return (
        <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
                <div className="relative">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center shadow-lg group-hover:shadow-primary-500/20">
                        <span className="text-lg font-semibold text-white">
                            {name.charAt(0)}
                        </span>
                    </div>
                    <StatusDot status={status} />
                </div>
                <div>
                    <h3 className="text-lg font-semibold text-white group-hover:text-primary-400 transition-colors">
                        {name}
                    </h3>
                    <div className="flex items-center text-sm text-gray-400">
                        <GlobeIcon />
                        {domain}
                    </div>
                </div>
            </div>
            <GitHubLink url={githubUrl} />
        </div>
    );
}

function MetricsSection({ revenue, revenueTrend, users, usersTrend }) {
    return (
        <div className="grid grid-cols-2 gap-4 mb-6">
            <MetricCard
                icon="💰"
                label="Revenue"
                value={`$${revenue.toLocaleString()}`}
                trend={revenueTrend}
            />
            <MetricCard
                icon="👥"
                label="Users"
                value={users.toLocaleString()}
                trend={usersTrend}
            />
        </div>
    );
}

function MetricCard({ icon, label, value, trend }) {
    return (
        <div className="bg-gray-900/50 backdrop-blur rounded-lg p-4 border border-gray-700/50">
            <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                    <span className="text-lg">{icon}</span>
                    <span className="text-sm text-gray-400">{label}</span>
                </div>
                <TrendIndicator value={trend} />
            </div>
            <div className="mt-1">
                <span className="text-xl font-bold text-white">{value}</span>
            </div>
        </div>
    );
}

function TrendIndicator({ value }) {
    return (
        <div className={`flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
            value >= 0 
                ? 'text-emerald-400 bg-emerald-400/10' 
                : 'text-rose-400 bg-rose-400/10'
        }`}>
            {value >= 0 ? '↑' : '↓'}{Math.abs(value)}%
        </div>
    );
}

function TechStack({ hosting, database, auth }) {
    return (
        <div className="flex flex-wrap gap-2 mb-6">
            {hosting && (
                <TechBadge label={hosting} type="primary" />
            )}
            {database && (
                <TechBadge label={database} type="success" />
            )}
            {auth && (
                <TechBadge label={auth} type="warning" />
            )}
        </div>
    );
}

function TechBadge({ label, type }) {
    const styles = {
        primary: 'text-primary-300 bg-primary-900/30 border-primary-700/30',
        success: 'text-emerald-300 bg-emerald-900/30 border-emerald-700/30',
        warning: 'text-amber-300 bg-amber-900/30 border-amber-700/30'
    };

    return (
        <span className={`px-3 py-1 text-xs font-medium rounded-full border ${styles[type]}`}>
            {label}
        </span>
    );
}

function StatusFooter({ uptime, responseTime }) {
    return (
        <div className="flex items-center justify-between pt-4 border-t border-gray-700/50">
            <div className="flex gap-4">
                <StatusMetric
                    value={`${uptime}% uptime`}
                    isHealthy={uptime >= 99.9}
                />
                <StatusMetric
                    value={`${responseTime}ms`}
                    isHealthy={responseTime <= 200}
                />
            </div>
            <DetailsButton />
        </div>
    );
}

function StatusMetric({ value, isHealthy }) {
    return (
        <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
                isHealthy ? 'bg-emerald-500' : 'bg-amber-500'
            }`} />
            <span className="text-sm text-gray-400">{value}</span>
        </div>
    );
}

function StatusDot({ status }) {
    return (
        <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-gray-800 shadow-lg ${
            status === 'healthy' ? 'bg-emerald-500' :
            status === 'warning' ? 'bg-amber-500' :
            'bg-rose-500'
        }`} />
    );
}

function GitHubLink({ url }) {
    return (
        <a 
            href={url}
            target="_blank"
            rel="noopener noreferrer" 
            className="p-2 text-gray-400 hover:text-white transition-colors"
            onClick={(e) => e.stopPropagation()}
        >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.17 6.839 9.49.5.092.682-.217.682-.48 0-.237-.009-.866-.013-1.7-2.782.603-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.464-1.11-1.464-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836c.85.004 1.705.114 2.504.336 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.17 22 16.42 22 12c0-5.523-4.477-10-10-10z" />
            </svg>
        </a>
    );
}

function GlobeIcon() {
    return (
        <svg className="w-4 h-4 mr-1 opacity-60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
        </svg>
    );
}

function DetailsButton() {
    return (
        <button className="text-sm text-gray-400 hover:text-white flex items-center gap-1 transition-colors">
            Details
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
            </svg>
        </button>
    );
}
