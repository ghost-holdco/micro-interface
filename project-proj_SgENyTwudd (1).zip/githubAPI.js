function GitHubAPI() {
    async function validateCredentials(config) {
        try {
            const response = await fetch('https://api.github.com/user', {
                headers: {
                    'Authorization': `token ${config.token}`,
                    'Accept': 'application/vnd.github.v3+json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            return true;
        } catch (error) {
            reportError(error);
            return false;
        }
    }

    async function fetchData(config) {
        try {
            const [userResponse, reposResponse] = await Promise.all([
                fetch('https://api.github.com/user', {
                    headers: {
                        'Authorization': `token ${config.token}`,
                        'Accept': 'application/vnd.github.v3+json'
                    }
                }),
                fetch(`https://api.github.com/repos/${config.owner}/${config.repo}`, {
                    headers: {
                        'Authorization': `token ${config.token}`,
                        'Accept': 'application/vnd.github.v3+json'
                    }
                })
            ]);

            if (!userResponse.ok || !reposResponse.ok) {
                throw new Error('Failed to fetch GitHub data');
            }

            const [userData, repoData] = await Promise.all([
                userResponse.json(),
                reposResponse.json()
            ]);

            return {
                repository: {
                    name: repoData.name,
                    stars: repoData.stargazers_count,
                    forks: repoData.forks_count,
                    openIssues: repoData.open_issues_count,
                    lastUpdate: repoData.updated_at,
                    language: repoData.language,
                    visibility: repoData.visibility
                },
                user: {
                    login: userData.login,
                    avatarUrl: userData.avatar_url,
                    type: userData.type
                }
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        validateCredentials,
        fetchData
    };
}
