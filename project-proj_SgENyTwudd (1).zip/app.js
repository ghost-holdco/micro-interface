function App() {
    const [selectedProduct, setSelectedProduct] = React.useState(null);
    const [products, setProducts] = React.useState([]);
    const [isFormOpen, setIsFormOpen] = React.useState(false);
    const [isLoading, setIsLoading] = React.useState(true);
    const [view, setView] = React.useState('grid'); // 'grid' or 'detail'
    const productAPI = TestProductAPI(); // Use TestProductAPI for development

    React.useEffect(() => {
        loadProducts();
    }, []);

    async function loadProducts() {
        try {
            setIsLoading(true);
            const prods = await productAPI.getProducts();
            console.log('Loaded products:', prods); // Add logging
            setProducts(prods);
        } catch (error) {
            reportError(error);
        } finally {
            setIsLoading(false);
        }
    }

    async function handleAddProduct(productData) {
        try {
            const newProduct = await productAPI.addProduct(productData);
            setProducts(prev => [...prev, newProduct]);
            setIsFormOpen(false);
        } catch (error) {
            reportError(error);
        }
    }

    function handleProductSelect(product) {
        console.log('Selected product:', product); // Add logging
        setSelectedProduct(product);
        setView('detail');
    }

    function handleBackToGrid() {
        setSelectedProduct(null);
        setView('grid');
    }

    if (isLoading) {
        return <LoadingOverlay message="Loading your products..." />;
    }

    return (
        <div data-name="app-container" className="min-h-screen bg-gray-900">
            <Header 
                selectedProduct={selectedProduct} 
                onProductSelect={setSelectedProduct}
                onBackToGrid={handleBackToGrid}
                view={view}
            />
            
            <main data-name="main-content" className="container mx-auto px-4 py-8">
                {view === 'detail' && selectedProduct ? (
                    <div className="max-w-6xl mx-auto">
                        <button
                            onClick={handleBackToGrid}
                            className="mb-6 flex items-center text-gray-400 hover:text-white transition-colors"
                        >
                            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
                            </svg>
                            Back to Overview
                        </button>
                        <ProductCard product={selectedProduct} />
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {products.map(product => (
                            <ProductOverviewCard 
                                key={product.objectId}
                                product={product}
                                onClick={() => handleProductSelect(product)}
                            />
                        ))}
                        {products.length === 0 && (
                            <div className="col-span-full text-center py-12">
                                <div className="text-6xl mb-4">🚀</div>
                                <h3 className="text-xl font-semibold text-white mb-2">No products yet</h3>
                                <p className="text-gray-400 mb-6">Start by adding your first Micro-SaaS product</p>
                            </div>
                        )}
                    </div>
                )}
            </main>

            <AddProductButton onClick={() => setIsFormOpen(true)} />

            <AddProductModal isOpen={isFormOpen} onClose={() => setIsFormOpen(false)}>
                <ProductFormWizard 
                    onSubmit={handleAddProduct}
                    onClose={() => setIsFormOpen(false)}
                />
            </AddProductModal>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
