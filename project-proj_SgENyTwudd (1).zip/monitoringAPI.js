function MonitoringAPI() {
    async function validateCredentials(config) {
        try {
            switch (config.provider) {
                case 'datadog':
                    return await validateDatadog(config);
                case 'newrelic':
                    return await validateNewRelic(config);
                default:
                    throw new Error(`Unsupported monitoring provider: ${config.provider}`);
            }
        } catch (error) {
            reportError(error);
            return false;
        }
    }

    async function fetchData(config) {
        try {
            switch (config.provider) {
                case 'datadog':
                    return await fetchDatadogMetrics(config);
                case 'newrelic':
                    return await fetchNewRelicMetrics(config);
                default:
                    throw new Error(`Unsupported monitoring provider: ${config.provider}`);
            }
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function validateDatadog(config) {
        try {
            const response = await fetch('https://api.datadoghq.com/api/v1/validate', {
                headers: {
                    'DD-API-KEY': config.apiKey,
                    'DD-APPLICATION-KEY': config.appKey
                }
            });

            return response.ok;
        } catch (error) {
            reportError(error);
            return false;
        }
    }

    async function validateNewRelic(config) {
        try {
            const response = await fetch('https://api.newrelic.com/v2/applications.json', {
                headers: {
                    'X-Api-Key': config.apiKey
                }
            });

            return response.ok;
        } catch (error) {
            reportError(error);
            return false;
        }
    }

    async function fetchDatadogMetrics(config) {
        try {
            const now = Math.floor(Date.now() / 1000);
            const from = now - 3600; // Last hour

            const response = await fetch(
                `https://api.datadoghq.com/api/v1/metrics?from=${from}&to=${now}`,
                {
                    headers: {
                        'DD-API-KEY': config.apiKey,
                        'DD-APPLICATION-KEY': config.appKey
                    }
                }
            );

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            const data = await response.json();

            return {
                provider: 'datadog',
                metrics: {
                    cpu: data.cpu_usage?.avg || 0,
                    memory: data.memory_usage?.avg || 0,
                    requests: data.request_count?.sum || 0,
                    errors: data.error_count?.sum || 0,
                    latency: data.latency?.avg || 0
                }
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function fetchNewRelicMetrics(config) {
        try {
            const response = await fetch(
                `https://api.newrelic.com/v2/applications/${config.appId}/metrics/data.json`,
                {
                    headers: {
                        'X-Api-Key': config.apiKey
                    }
                }
            );

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            const data = await response.json();

            return {
                provider: 'newrelic',
                metrics: {
                    apdex: data.metric_data.metrics[0]?.timeslices[0]?.values.score || 0,
                    errorRate: data.metric_data.metrics[1]?.timeslices[0]?.values.error_rate || 0,
                    throughput: data.metric_data.metrics[2]?.timeslices[0]?.values.requests_per_minute || 0,
                    responseTime: data.metric_data.metrics[3]?.timeslices[0]?.values.average_response_time || 0
                }
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        validateCredentials,
        fetchData
    };
}
