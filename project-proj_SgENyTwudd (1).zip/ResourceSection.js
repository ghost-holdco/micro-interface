function ResourceSection({ product, onUpdateResource }) {
    const [selectedResource, setSelectedResource] = React.useState(null);
    const [isAddingResource, setIsAddingResource] = React.useState(false);

    const resourceCategories = [
        {
            title: "Infrastructure",
            icon: "🏗️",
            resources: [
                { key: "hosting", label: "Hosting", value: product.hosting, icon: "🏢" },
                { key: "database", label: "Database", value: product.database, icon: "💾" },
                { key: "storage", label: "Storage", value: product.imageStorage, icon: "📁" },
                { key: "auth", label: "Authentication", value: product.auth, icon: "🔐" }
            ]
        },
        {
            title: "Monitoring & Analytics",
            icon: "📊",
            resources: [
                { key: "analytics", label: "Analytics", value: product.analytics, icon: "📈" },
                { key: "errorTracking", label: "Error Tracking", value: product.errorTracking, icon: "🐛" },
                { key: "seoTool", label: "SEO Tools", value: product.seoTool, icon: "🎯" }
            ]
        },
        {
            title: "Communication",
            icon: "💬",
            resources: [
                { key: "emailService", label: "Email Service", value: product.emailMarketing, icon: "📧" },
                { key: "notifications", label: "Notifications", value: product.notifications, icon: "🔔" },
                { key: "support", label: "Customer Support", value: product.customerSupport, icon: "💭" }
            ]
        }
    ];

    return (
        <div className="space-y-6">
            {/* Resource Categories */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {resourceCategories.map(category => (
                    <ResourceCategory
                        key={category.title}
                        category={category}
                        onResourceClick={setSelectedResource}
                    />
                ))}
            </div>

            {/* Add Resource Button */}
            <button
                onClick={() => setIsAddingResource(true)}
                className="flex items-center justify-center w-full p-4 border-2 border-dashed border-gray-700 rounded-xl text-gray-500 hover:text-gray-300 hover:border-gray-500 transition-colors duration-200"
            >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
                </svg>
                Add New Resource
            </button>

            {/* Resource Edit Modal */}
            {selectedResource && (
                <ResourceEditModal
                    resource={selectedResource}
                    onClose={() => setSelectedResource(null)}
                    onSave={async (updatedResource) => {
                        await onUpdateResource(updatedResource);
                        setSelectedResource(null);
                    }}
                />
            )}

            {/* Add Resource Modal */}
            {isAddingResource && (
                <AddResourceModal
                    onClose={() => setIsAddingResource(false)}
                    onAdd={async (newResource) => {
                        await onUpdateResource(newResource);
                        setIsAddingResource(false);
                    }}
                />
            )}
        </div>
    );
}

function ResourceCategory({ category, onResourceClick }) {
    return (
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
            <div className="flex items-center space-x-3 mb-4">
                <span className="text-2xl">{category.icon}</span>
                <h3 className="text-lg font-semibold text-white">{category.title}</h3>
            </div>
            <div className="space-y-3">
                {category.resources.map(resource => (
                    <ResourceItem
                        key={resource.key}
                        resource={resource}
                        onClick={() => onResourceClick(resource)}
                    />
                ))}
            </div>
        </div>
    );
}

function ResourceItem({ resource, onClick }) {
    return (
        <button
            onClick={onClick}
            className="w-full flex items-center justify-between p-3 rounded-lg border border-gray-700 hover:border-primary-500/50 hover:bg-gray-700/50 transition-all duration-200"
        >
            <div className="flex items-center space-x-3">
                <span className="text-xl">{resource.icon}</span>
                <div className="text-left">
                    <p className="text-sm font-medium text-white">{resource.label}</p>
                    <p className="text-xs text-gray-400">{resource.value || 'Not configured'}</p>
                </div>
            </div>
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
            </svg>
        </button>
    );
}
