function VercelAPI() {
    async function validateCredentials(config) {
        try {
            const response = await fetch('https://api.vercel.com/v2/user', {
                headers: {
                    'Authorization': `Bearer ${config.token}`
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            return true;
        } catch (error) {
            reportError(error);
            return false;
        }
    }

    async function fetchData(config) {
        try {
            const [deployments, analytics] = await Promise.all([
                fetch(`https://api.vercel.com/v6/deployments?projectId=${config.projectId}`, {
                    headers: {
                        'Authorization': `Bearer ${config.token}`
                    }
                }),
                fetch(`https://api.vercel.com/v2/analytics/usage?projectId=${config.projectId}`, {
                    headers: {
                        'Authorization': `Bearer ${config.token}`
                    }
                })
            ]);

            if (!deployments.ok || !analytics.ok) {
                throw new Error('Failed to fetch Vercel data');
            }

            const [deploymentsData, analyticsData] = await Promise.all([
                deployments.json(),
                analytics.json()
            ]);

            return {
                deployments: deploymentsData.deployments.map(d => ({
                    id: d.uid,
                    url: d.url,
                    state: d.state,
                    createdAt: d.created,
                    branch: d.meta?.branch || 'unknown'
                })),
                analytics: {
                    bandwidth: analyticsData.bandwidth.used,
                    executions: analyticsData.executions.used,
                    logs: analyticsData.logs.used
                }
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        validateCredentials,
        fetchData
    };
}
