function FormField({ 
    name, 
    label, 
    value, 
    onChange, 
    type = "text", 
    options = [], 
    required = false, 
    placeholder = "",
    error = "",
    helpText = "",
    disabled = false,
    className = "",
    loading = false
}) {
    const [isFocused, setIsFocused] = React.useState(false);
    const [showHelp, setShowHelp] = React.useState(false);
    const inputId = `form-field-${name}`;
    const helpId = `help-${inputId}`;

    const handleFocus = () => setIsFocused(true);
    const handleBlur = () => setIsFocused(false);

    const baseInputClasses = `
        w-full rounded-lg px-3 py-2 text-sm 
        transition-all duration-200 ease-in-out
        ${disabled ? 'opacity-50 cursor-not-allowed bg-gray-50' : 'bg-white hover:border-gray-400'}
        ${error ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 
                 'border-gray-200 focus:border-primary-500 focus:ring-primary-500'}
        ${isFocused ? 'ring-2 ring-opacity-50' : ''}
        ${className}
    `;

    return (
        <div data-name={`form-field-${name}`} className="w-full">
            <div className="flex justify-between items-center mb-1">
                <label 
                    htmlFor={inputId}
                    className="block text-sm font-medium text-gray-700"
                >
                    {label}
                    {required && <span className="text-red-500 ml-1">*</span>}
                </label>
                {helpText && (
                    <div 
                        className="relative"
                        onMouseEnter={() => setShowHelp(true)}
                        onMouseLeave={() => setShowHelp(false)}
                    >
                        <button
                            type="button"
                            className="text-gray-400 hover:text-gray-500 focus:outline-none"
                            aria-label="Show help text"
                        >
                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                            </svg>
                        </button>
                        {showHelp && (
                            <div className="absolute z-10 w-48 px-2 py-1 mt-1 text-sm text-gray-600 bg-white rounded-md shadow-lg border border-gray-200">
                                {helpText}
                            </div>
                        )}
                    </div>
                )}
            </div>

            <div className="relative">
                {type === "select" ? (
                    <div className="relative">
                        <select
                            id={inputId}
                            name={name}
                            value={value}
                            onChange={onChange}
                            onFocus={handleFocus}
                            onBlur={handleBlur}
                            disabled={disabled || loading}
                            required={required}
                            className={baseInputClasses}
                            aria-describedby={helpText ? helpId : undefined}
                        >
                            <option value="">Select {label}</option>
                            {options.map(option => (
                                <option 
                                    key={typeof option === 'object' ? option.value : option} 
                                    value={typeof option === 'object' ? option.value : option}
                                >
                                    {typeof option === 'object' ? option.label : option}
                                </option>
                            ))}
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>
                ) : type === "textarea" ? (
                    <textarea
                        id={inputId}
                        name={name}
                        value={value}
                        onChange={onChange}
                        onFocus={handleFocus}
                        onBlur={handleBlur}
                        placeholder={placeholder}
                        disabled={disabled || loading}
                        required={required}
                        className={`${baseInputClasses} min-h-[100px] resize-y`}
                        aria-describedby={helpText ? helpId : undefined}
                    />
                ) : type === "checkbox" ? (
                    <div className="flex items-center">
                        <input
                            id={inputId}
                            type="checkbox"
                            name={name}
                            checked={value}
                            onChange={onChange}
                            disabled={disabled || loading}
                            required={required}
                            className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500 transition duration-150 ease-in-out"
                        />
                        <label 
                            htmlFor={inputId}
                            className="ml-2 block text-sm text-gray-700"
                        >
                            {label}
                        </label>
                    </div>
                ) : (
                    <div className="relative">
                        <input
                            id={inputId}
                            type={type}
                            name={name}
                            value={value}
                            onChange={onChange}
                            onFocus={handleFocus}
                            onBlur={handleBlur}
                            placeholder={placeholder}
                            disabled={disabled || loading}
                            required={required}
                            className={baseInputClasses}
                            aria-describedby={helpText ? helpId : undefined}
                        />
                        {loading && (
                            <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                                <LoadingSpinner size="small" />
                            </div>
                        )}
                    </div>
                )}
            </div>

            {error && (
                <p className="mt-1 text-xs text-red-500" role="alert">
                    {error}
                </p>
            )}
        </div>
    );
}
