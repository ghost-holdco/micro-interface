function ProductFormWizard({ onSubmit, onClose }) {
    const [step, setStep] = React.useState(1);
    const [formData, setFormData] = React.useState({
        name: '',
        type: 'Micro-SaaS',
        githubUrl: '',
        domain: '',
        hosting: '',
        database: '',
        imageStorage: '',
        auth: '',
        analytics: '',
        errorTracking: '',
        seoTool: '',
        emailMarketing: '',
        notifications: '',
        customerSupport: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        try {
            onSubmit(formData);
            onClose();
        } catch (error) {
            reportError(error);
        }
    };

    const steps = [
        {
            title: "Basic Information",
            description: "Let's start with the essentials",
            icon: "✨",
            fields: (
                <div className="grid grid-cols-1 gap-6">
                    <FormField
                        name="name"
                        label="Product Name"
                        value={formData.name}
                        onChange={handleChange}
                        required={true}
                        placeholder="Enter your product name"
                        helpText="Choose a memorable name for your Micro-SaaS"
                    />
                    <FormField
                        name="domain"
                        label="Domain"
                        value={formData.domain}
                        onChange={handleChange}
                        placeholder="app.example.com"
                        required={true}
                        helpText="The domain where your product is hosted"
                    />
                    <FormField
                        name="githubUrl"
                        label="GitHub Repository"
                        value={formData.githubUrl}
                        onChange={handleChange}
                        placeholder="https://github.com/username/repo"
                        required={true}
                        helpText="Link to your product's source code"
                    />
                </div>
            )
        },
        {
            title: "Infrastructure",
            description: "Configure your tech stack",
            icon: "🏗️",
            fields: (
                <div className="grid grid-cols-2 gap-6">
                    <FormField
                        name="hosting"
                        label="Hosting Provider"
                        value={formData.hosting}
                        onChange={handleChange}
                        type="select"
                        options={[
                            { value: 'vercel', label: 'Vercel' },
                            { value: 'netlify', label: 'Netlify' },
                            { value: 'aws', label: 'AWS' },
                            { value: 'digitalocean', label: 'DigitalOcean' },
                            { value: 'other', label: 'Other' }
                        ]}
                        helpText="Where your application is deployed"
                    />
                    <FormField
                        name="database"
                        label="Database"
                        value={formData.database}
                        onChange={handleChange}
                        type="select"
                        options={[
                            { value: 'supabase', label: 'Supabase' },
                            { value: 'firebase', label: 'Firebase' },
                            { value: 'mongodb', label: 'MongoDB' },
                            { value: 'postgresql', label: 'PostgreSQL' },
                            { value: 'other', label: 'Other' }
                        ]}
                        helpText="Your primary data storage solution"
                    />
                    <FormField
                        name="imageStorage"
                        label="File Storage"
                        value={formData.imageStorage}
                        onChange={handleChange}
                        type="select"
                        options={[
                            { value: 's3', label: 'AWS S3' },
                            { value: 'cloudinary', label: 'Cloudinary' },
                            { value: 'firebase', label: 'Firebase Storage' },
                            { value: 'other', label: 'Other' }
                        ]}
                        helpText="Where you store user uploads and media"
                    />
                    <FormField
                        name="auth"
                        label="Authentication"
                        value={formData.auth}
                        onChange={handleChange}
                        type="select"
                        options={[
                            { value: 'google', label: 'Google OAuth' },
                            { value: 'auth0', label: 'Auth0' },
                            { value: 'firebase', label: 'Firebase Auth' },
                            { value: 'custom', label: 'Custom Solution' },
                            { value: 'other', label: 'Other' }
                        ]}
                        helpText="How users sign in to your application"
                    />
                </div>
            )
        },
        {
            title: "Monitoring & Analytics",
            description: "Track your product's performance",
            icon: "📊",
            fields: (
                <div className="grid grid-cols-2 gap-6">
                    <FormField
                        name="analytics"
                        label="Analytics Platform"
                        value={formData.analytics}
                        onChange={handleChange}
                        type="select"
                        options={[
                            { value: 'plausible', label: 'Plausible' },
                            { value: 'ga4', label: 'Google Analytics 4' },
                            { value: 'mixpanel', label: 'Mixpanel' },
                            { value: 'other', label: 'Other' }
                        ]}
                        helpText="Track user behavior and engagement"
                    />
                    <FormField
                        name="errorTracking"
                        label="Error Monitoring"
                        value={formData.errorTracking}
                        onChange={handleChange}
                        type="select"
                        options={[
                            { value: 'sentry', label: 'Sentry' },
                            { value: 'rollbar', label: 'Rollbar' },
                            { value: 'logrocket', label: 'LogRocket' },
                            { value: 'other', label: 'Other' }
                        ]}
                        helpText="Monitor and debug issues in production"
                    />
                </div>
            )
        }
    ];

    return (
        <div className="p-8">
            {/* Progress Bar and Steps */}
            <div className="mb-8">
                <div className="flex justify-between mb-4">
                    {steps.map((s, i) => (
                        <button
                            key={i}
                            onClick={() => setStep(i + 1)}
                            className={`flex flex-col items-center w-1/3 relative ${
                                step === i + 1 ? 'text-primary-600' : 'text-gray-400'
                            }`}
                        >
                            <div className={`
                                w-10 h-10 rounded-full flex items-center justify-center mb-2
                                ${step === i + 1 ? 'bg-primary-100 text-primary-600' : 
                                  step > i + 1 ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-400'}
                            `}>
                                {step > i + 1 ? '✓' : s.icon}
                            </div>
                            <div className="text-sm font-medium">{s.title}</div>
                            <div className="text-xs text-gray-400">{s.description}</div>
                        </button>
                    ))}
                </div>
                <div className="relative pt-4">
                    <div className="w-full h-2 bg-gray-100 rounded-full">
                        <div
                            className="h-full bg-primary-600 rounded-full transition-all duration-300"
                            style={{ width: `${((step - 1) / (steps.length - 1)) * 100}%` }}
                        ></div>
                    </div>
                </div>
            </div>

            {/* Form Content */}
            <form onSubmit={handleSubmit}>
                <div className="mb-8">
                    <div className="max-w-2xl mx-auto">
                        {steps[step - 1].fields}
                    </div>
                </div>

                {/* Navigation Buttons */}
                <div className="flex justify-between mt-8">
                    <button
                        type="button"
                        onClick={() => setStep(s => Math.max(1, s - 1))}
                        className={`px-6 py-2 rounded-lg font-medium transition-colors duration-200 
                            ${step === 1 ? 'invisible' : 'text-gray-600 hover:text-gray-800'}`}
                    >
                        ← Previous
                    </button>
                    {step < steps.length ? (
                        <button
                            type="button"
                            onClick={() => setStep(s => Math.min(steps.length, s + 1))}
                            className="px-6 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 
                                     transition-colors duration-200 flex items-center"
                        >
                            Next
                            <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                    ) : (
                        <button
                            type="submit"
                            className="px-6 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 
                                     transition-colors duration-200 flex items-center"
                        >
                            Complete Setup
                            <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                            </svg>
                        </button>
                    )}
                </div>
            </form>
        </div>
    );
}
