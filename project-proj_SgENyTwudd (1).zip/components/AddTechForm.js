function AddTechForm({ onSubmit }) {
    const [formData, setFormData] = React.useState({
        name: '',
        category: '',
        description: '',
        version: ''
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        try {
            onSubmit(formData);
            setFormData({ name: '', category: '', description: '', version: '' });
        } catch (error) {
            reportError(error);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    return (
        <form data-name="add-tech-form" onSubmit={handleSubmit} className="bg-white p-4 rounded-lg shadow-md">
            <h2 data-name="form-title" className="text-lg font-semibold mb-4">Add New Technology</h2>
            <div className="space-y-4">
                <div>
                    <label data-name="name-label" className="block text-sm font-medium text-gray-700">Name</label>
                    <input
                        data-name="name-input"
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        required
                    />
                </div>
                <div>
                    <label data-name="category-label" className="block text-sm font-medium text-gray-700">Category</label>
                    <input
                        data-name="category-input"
                        type="text"
                        name="category"
                        value={formData.category}
                        onChange={handleChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        required
                    />
                </div>
                <div>
                    <label data-name="description-label" className="block text-sm font-medium text-gray-700">Description</label>
                    <textarea
                        data-name="description-input"
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        rows="3"
                        required
                    ></textarea>
                </div>
                <div>
                    <label data-name="version-label" className="block text-sm font-medium text-gray-700">Version</label>
                    <input
                        data-name="version-input"
                        type="text"
                        name="version"
                        value={formData.version}
                        onChange={handleChange}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        required
                    />
                </div>
                <button
                    data-name="submit-button"
                    type="submit"
                    className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                    Add Technology
                </button>
            </div>
        </form>
    );
}
