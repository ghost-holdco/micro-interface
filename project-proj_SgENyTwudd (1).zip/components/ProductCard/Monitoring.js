function Monitoring({ metrics }) {
    console.log('Monitoring component metrics:', metrics); // Debug log

    return (
        <div className="space-y-6">
            {/* System Health Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <MonitoringCard
                    title="System Status"
                    status={metrics.status}
                    metrics={[
                        { label: 'Uptime', value: `${metrics.uptime}%` },
                        { label: 'Response Time', value: `${metrics.responseTime}ms` }
                    ]}
                    trend={{
                        value: metrics.uptime,
                        change: 0.03,
                        period: 'vs last 30 days'
                    }}
                />
                <MonitoringCard
                    title="SSL Certificate"
                    status={metrics.sslHealth}
                    metrics={[
                        { label: 'Status', value: metrics.sslStatus },
                        { label: 'Expiry', value: '87 days' }
                    ]}
                    trend={{
                        value: 'A+',
                        change: 0,
                        period: 'Grade unchanged'
                    }}
                />
                <MonitoringCard
                    title="Performance"
                    status={metrics.responseStatus}
                    metrics={[
                        { label: 'Score', value: `${metrics.performance}/100` },
                        { label: 'Load Time', value: `${metrics.responseTime}ms` }
                    ]}
                    trend={{
                        value: metrics.performance,
                        change: 5,
                        period: 'vs last week'
                    }}
                />
            </div>

            {/* System Metrics */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
                <div className="flex justify-between items-center mb-6">
                    <div>
                        <h3 className="text-lg font-semibold text-gray-900">System Metrics</h3>
                        <p className="text-sm text-gray-500">Key performance indicators</p>
                    </div>
                    <select className="text-sm border border-gray-200 rounded-lg px-3 py-2">
                        <option>Last 24 hours</option>
                        <option>Last 7 days</option>
                        <option>Last 30 days</option>
                    </select>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <MetricTile
                        label="CPU Usage"
                        value="32%"
                        trend={-5}
                        status="healthy"
                    />
                    <MetricTile
                        label="Memory Usage"
                        value="68%"
                        trend={+12}
                        status="warning"
                    />
                    <MetricTile
                        label="Disk Space"
                        value="45%"
                        trend={+3}
                        status="healthy"
                    />
                    <MetricTile
                        label="Network I/O"
                        value="1.2 GB/s"
                        trend={+8}
                        status="healthy"
                    />
                </div>
            </div>

            {/* Recent Incidents */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
                <div className="flex justify-between items-center mb-6">
                    <div>
                        <h3 className="text-lg font-semibold text-gray-900">Recent Incidents</h3>
                        <p className="text-sm text-gray-500">System incidents and resolutions</p>
                    </div>
                    <select className="text-sm border border-gray-200 rounded-lg px-3 py-2">
                        <option>Last 7 days</option>
                        <option>Last 30 days</option>
                        <option>Last 90 days</option>
                    </select>
                </div>
                <IncidentHistory incidents={metrics.incidents || []} />
            </div>
        </div>
    );
}

function MonitoringCard({ title, status, metrics, trend }) {
    const statusColors = {
        healthy: 'bg-emerald-400',
        warning: 'bg-amber-400',
        error: 'bg-rose-400'
    };

    return (
        <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
                <div className={`w-3 h-3 rounded-full ${statusColors[status]}`} />
            </div>

            <div className="space-y-3">
                {metrics.map((metric, index) => (
                    <div key={index} className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">{metric.label}</span>
                        <span className="text-sm font-medium text-gray-900">{metric.value}</span>
                    </div>
                ))}
            </div>

            {trend && (
                <div className="mt-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-500">{trend.period}</span>
                        <div className="flex items-center space-x-1">
                            {trend.change > 0 ? (
                                <span className="text-emerald-500">↑</span>
                            ) : trend.change < 0 ? (
                                <span className="text-rose-500">↓</span>
                            ) : (
                                <span className="text-gray-500">→</span>
                            )}
                            <span className={`text-sm font-medium ${
                                trend.change > 0 ? 'text-emerald-600' :
                                trend.change < 0 ? 'text-rose-600' :
                                'text-gray-600'
                            }`}>
                                {trend.change ? `${Math.abs(trend.change)}%` : 'No change'}
                            </span>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

function MetricTile({ label, value, trend, status }) {
    const statusColors = {
        healthy: 'bg-emerald-400',
        warning: 'bg-amber-400',
        error: 'bg-rose-400'
    };

    return (
        <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">{label}</span>
                <div className={`w-2 h-2 rounded-full ${statusColors[status]}`} />
            </div>
            <div className="text-2xl font-bold text-gray-900">{value}</div>
            <div className={`text-sm font-medium ${
                trend > 0 ? 'text-emerald-600' : 'text-rose-600'
            } flex items-center mt-1`}>
                {trend > 0 ? '↑' : '↓'}{Math.abs(trend)}%
                <span className="text-gray-500 ml-1">vs last period</span>
            </div>
        </div>
    );
}

function IncidentHistory({ incidents }) {
    if (!incidents || incidents.length === 0) {
        return (
            <div className="text-center py-8 text-gray-500">
                No incidents reported
            </div>
        );
    }

    return (
        <div className="space-y-4">
            {incidents.map((incident, index) => (
                <div 
                    key={index}
                    className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg"
                >
                    <div className="flex-shrink-0">
                        <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
                            <span className="text-red-600 text-lg">⚠️</span>
                        </div>
                    </div>
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                            <p className="text-sm font-medium text-gray-900">
                                {incident.type}
                            </p>
                            <span className="text-sm text-gray-500">
                                {incident.duration}
                            </span>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                            Affected: {incident.affected}
                        </p>
                        <p className="text-xs text-gray-400 mt-1">
                            {new Date(incident.date).toLocaleDateString()}
                        </p>
                    </div>
                </div>
            ))}
        </div>
    );
}
