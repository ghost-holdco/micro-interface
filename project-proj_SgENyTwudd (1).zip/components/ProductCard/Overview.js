function Overview({ product, metrics }) {
    console.log('Overview props:', { product, metrics }); // Add logging to debug
    return (
        <div className="space-y-6">
            {/* Key Performance Indicators */}
            <KPIMetrics metrics={metrics} />

            {/* Traffic and Engagement Analysis */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
                    <div className="flex justify-between items-center mb-6">
                        <div>
                            <h3 className="text-lg font-semibold text-gray-900">Traffic Sources</h3>
                            <p className="text-sm text-gray-500">Distribution of user acquisition channels</p>
                        </div>
                        <select className="text-sm border border-gray-200 rounded-lg px-3 py-2">
                            <option>Last 7 days</option>
                            <option>Last 30 days</option>
                            <option>Last 90 days</option>
                        </select>
                    </div>
                    <TrafficSourcesChart data={metrics.traffic} />
                </div>

                <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
                    <div className="flex justify-between items-center mb-6">
                        <div>
                            <h3 className="text-lg font-semibold text-gray-900">User Engagement</h3>
                            <p className="text-sm text-gray-500">Key engagement metrics and trends</p>
                        </div>
                        <select className="text-sm border border-gray-200 rounded-lg px-3 py-2">
                            <option>Last 7 days</option>
                            <option>Last 30 days</option>
                            <option>Last 90 days</option>
                        </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <EngagementMetricCard
                            title="Session Duration"
                            value={`${metrics.engagement.averageSession}m`}
                            trend={metrics.engagement.sessionTrend}
                            description="Average time spent per session"
                            icon="⏱️"
                        />
                        <EngagementMetricCard
                            title="Bounce Rate"
                            value={`${metrics.engagement.bounceRate}%`}
                            trend={metrics.engagement.bounceTrend}
                            description="Single-page session percentage"
                            inverseTrend={true}
                            icon="↩️"
                        />
                        <EngagementMetricCard
                            title="Retention Rate"
                            value={`${metrics.engagement.retention}%`}
                            trend={metrics.engagement.retentionTrend}
                            description="Returning user percentage"
                            icon="🎯"
                        />
                        <EngagementMetricCard
                            title="Pages per Visit"
                            value="4.2"
                            trend={5.2}
                            description="Average pages viewed per session"
                            icon="📑"
                        />
                    </div>
                </div>
            </div>

            {/* Quick Actions and Links */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <QuickLink
                    title="GitHub Repository"
                    icon="📦"
                    href={product.githubUrl}
                    metrics={[
                        { label: 'Stars', value: '24' },
                        { label: 'Open PRs', value: '3' }
                    ]}
                />
                <QuickLink
                    title="Analytics Dashboard"
                    icon="📊"
                    href={metrics.analyticsUrl}
                    metrics={[
                        { label: 'Page Views', value: '2.4k' },
                        { label: 'Active Sessions', value: '1.8k' }
                    ]}
                />
                <QuickLink
                    title="System Logs"
                    icon="📝"
                    href={metrics.logsUrl}
                    metrics={[
                        { label: 'Error Rate', value: '0.1%' },
                        { label: 'Warnings', value: '2' }
                    ]}
                />
                <QuickLink
                    title="System Settings"
                    icon="⚙️"
                    href={metrics.settingsUrl}
                    metrics={[
                        { label: 'Pending Updates', value: '1' },
                        { label: 'Health Status', value: 'OK' }
                    ]}
                />
            </div>
        </div>
    );
}

function EngagementMetricCard({ title, value, trend, icon, description, inverseTrend = false }) {
    return (
        <div className="bg-gray-50 rounded-lg p-4 border border-gray-100">
            <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-600">{title}</span>
                <span className="text-lg">{icon}</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">{value}</div>
            <div className={`text-sm font-medium ${
                inverseTrend ? 
                    (trend < 0 ? 'text-emerald-600' : 'text-rose-600') :
                    (trend > 0 ? 'text-emerald-600' : 'text-rose-600')
            } flex items-center mt-1`}>
                {trend > 0 ? '↑' : '↓'}{Math.abs(trend)}%
                <span className="text-gray-500 ml-1">vs last period</span>
            </div>
            {description && (
                <p className="text-xs text-gray-500 mt-1">{description}</p>
            )}
        </div>
    );
}

function QuickLink({ title, icon, href, metrics }) {
    return (
        <a 
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="group bg-white rounded-xl p-4 border border-gray-200 hover:border-primary-500/50 transition-all duration-200 hover:shadow-sm"
        >
            <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-700 group-hover:text-gray-900">
                    {title}
                </span>
                <span className="text-lg group-hover:scale-110 transition-transform duration-200">
                    {icon}
                </span>
            </div>
            <div className="flex items-center justify-between">
                {metrics.map((metric, index) => (
                    <div key={index} className="text-center">
                        <div className="text-sm font-semibold text-gray-900">
                            {metric.value}
                        </div>
                        <div className="text-xs text-gray-500">
                            {metric.label}
                        </div>
                    </div>
                ))}
            </div>
        </a>
    );
}
