function ResourcesSection({ product, onUpdateResource }) {
    const [selectedResource, setSelectedResource] = React.useState(null);
    const [isAddingResource, setIsAddingResource] = React.useState(false);

    const resourceCategories = [
        {
            title: "Infrastructure",
            icon: "🏗️",
            resources: [
                { key: "hosting", label: "Hosting", value: product.hosting, icon: "🏢" },
                { key: "database", label: "Database", value: product.database, icon: "💾" },
                { key: "storage", label: "Storage", value: product.imageStorage, icon: "📁" },
                { key: "auth", label: "Authentication", value: product.auth, icon: "🔐" }
            ]
        },
        {
            title: "Monitoring & Analytics",
            icon: "📊",
            resources: [
                { key: "analytics", label: "Analytics", value: product.analytics, icon: "📈" },
                { key: "errorTracking", label: "Error Tracking", value: product.errorTracking, icon: "🐛" },
                { key: "seoTool", label: "SEO Tools", value: product.seoTool, icon: "🎯" }
            ]
        },
        {
            title: "Communication",
            icon: "💬",
            resources: [
                { key: "emailService", label: "Email Service", value: product.emailMarketing, icon: "📧" },
                { key: "notifications", label: "Notifications", value: product.notifications, icon: "🔔" },
                { key: "support", label: "Customer Support", value: product.customerSupport, icon: "💭" }
            ]
        }
    ];

    return (
        <div className="space-y-6">
            {/* Resource Categories */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {resourceCategories.map(category => (
                    <ResourceCategory
                        key={category.title}
                        category={category}
                        onResourceClick={setSelectedResource}
                    />
                ))}
            </div>

            {/* Add Resource Button */}
            <button
                onClick={() => setIsAddingResource(true)}
                className="flex items-center justify-center w-full p-4 border-2 border-dashed border-gray-300 rounded-xl text-gray-500 hover:text-gray-700 hover:border-gray-400 transition-colors duration-200"
            >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
                </svg>
                Add New Resource
            </button>

            {/* Resource Edit Modal */}
            {selectedResource && (
                <ResourceEditModal
                    resource={selectedResource}
                    onClose={() => setSelectedResource(null)}
                    onSave={async (updatedResource) => {
                        await onUpdateResource(updatedResource);
                        setSelectedResource(null);
                    }}
                />
            )}

            {/* Add Resource Modal */}
            {isAddingResource && (
                <AddResourceModal
                    onClose={() => setIsAddingResource(false)}
                    onAdd={async (newResource) => {
                        await onUpdateResource(newResource);
                        setIsAddingResource(false);
                    }}
                />
            )}
        </div>
    );
}

function ResourceCategory({ category, onResourceClick }) {
    return (
        <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
            <div className="flex items-center space-x-3 mb-4">
                <span className="text-2xl">{category.icon}</span>
                <h3 className="text-lg font-semibold text-gray-900">{category.title}</h3>
            </div>
            <div className="space-y-3">
                {category.resources.map(resource => (
                    <ResourceItem
                        key={resource.key}
                        resource={resource}
                        onClick={() => onResourceClick(resource)}
                    />
                ))}
            </div>
        </div>
    );
}

function ResourceItem({ resource, onClick }) {
    return (
        <button
            onClick={onClick}
            className="w-full flex items-center justify-between p-3 rounded-lg border border-gray-100 hover:border-primary-500/50 hover:shadow-sm transition-all duration-200"
        >
            <div className="flex items-center space-x-3">
                <span className="text-xl">{resource.icon}</span>
                <div className="text-left">
                    <p className="text-sm font-medium text-gray-900">{resource.label}</p>
                    <p className="text-xs text-gray-500">{resource.value}</p>
                </div>
            </div>
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
            </svg>
        </button>
    );
}

function ResourceEditModal({ resource, onClose, onSave }) {
    const [formData, setFormData] = React.useState({
        provider: resource.value,
        apiKey: '',
        config: {}
    });

    const providers = {
        hosting: ['Vercel', 'Netlify', 'AWS', 'DigitalOcean', 'Heroku'],
        database: ['Supabase', 'MongoDB', 'PostgreSQL', 'Firebase', 'MySQL'],
        storage: ['AWS S3', 'Cloudinary', 'Firebase Storage', 'DigitalOcean Spaces'],
        auth: ['Auth0', 'Firebase Auth', 'Supabase Auth', 'Custom'],
        analytics: ['Google Analytics', 'Plausible', 'Mixpanel', 'PostHog'],
        errorTracking: ['Sentry', 'Rollbar', 'LogRocket', 'TrackJS'],
        emailService: ['SendGrid', 'Mailgun', 'AWS SES', 'Postmark']
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl shadow-lg max-w-lg w-full">
                <div className="p-6">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-semibold text-gray-900">
                            Update {resource.label}
                        </h3>
                        <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>

                    <div className="space-y-4">
                        {/* Provider Selection */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Provider
                            </label>
                            <select
                                value={formData.provider}
                                onChange={(e) => setFormData({ ...formData, provider: e.target.value })}
                                className="w-full rounded-lg border border-gray-300 py-2 px-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                            >
                                {providers[resource.key]?.map(provider => (
                                    <option key={provider} value={provider}>{provider}</option>
                                ))}
                            </select>
                        </div>

                        {/* API Key */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                API Key
                            </label>
                            <input
                                type="password"
                                value={formData.apiKey}
                                onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                                className="w-full rounded-lg border border-gray-300 py-2 px-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                                placeholder="Enter API key"
                            />
                        </div>

                        {/* Additional Configuration */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Additional Configuration
                            </label>
                            <textarea
                                value={JSON.stringify(formData.config, null, 2)}
                                onChange={(e) => {
                                    try {
                                        const config = JSON.parse(e.target.value);
                                        setFormData({ ...formData, config });
                                    } catch (error) {
                                        // Handle invalid JSON
                                    }
                                }}
                                className="w-full rounded-lg border border-gray-300 py-2 px-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                                rows="4"
                                placeholder="{ }"
                            />
                        </div>
                    </div>

                    <div className="mt-6 flex justify-end space-x-3">
                        <button
                            onClick={onClose}
                            className="px-4 py-2 text-gray-700 hover:text-gray-900"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={() => onSave({ ...resource, value: formData.provider, config: formData })}
                            className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600"
                        >
                            Save Changes
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

function AddResourceModal({ onClose, onAdd }) {
    const [formData, setFormData] = React.useState({
        type: '',
        provider: '',
        apiKey: '',
        config: {}
    });

    const resourceTypes = [
        { key: 'hosting', label: 'Hosting Service' },
        { key: 'database', label: 'Database' },
        { key: 'storage', label: 'Storage' },
        { key: 'auth', label: 'Authentication' },
        { key: 'analytics', label: 'Analytics' },
        { key: 'monitoring', label: 'Monitoring' },
        { key: 'communication', label: 'Communication' }
    ];

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl shadow-lg max-w-lg w-full">
                <div className="p-6">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-semibold text-gray-900">
                            Add New Resource
                        </h3>
                        <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>

                    <div className="space-y-4">
                        {/* Resource Type */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Resource Type
                            </label>
                            <select
                                value={formData.type}
                                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                                className="w-full rounded-lg border border-gray-300 py-2 px-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                            >
                                <option value="">Select a resource type</option>
                                {resourceTypes.map(type => (
                                    <option key={type.key} value={type.key}>{type.label}</option>
                                ))}
                            </select>
                        </div>

                        {/* Provider */}
                        {formData.type && (
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Provider
                                </label>
                                <input
                                    type="text"
                                    value={formData.provider}
                                    onChange={(e) => setFormData({ ...formData, provider: e.target.value })}
                                    className="w-full rounded-lg border border-gray-300 py-2 px-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                                    placeholder="Enter provider name"
                                />
                            </div>
                        )}

                        {/* API Key */}
                        {formData.provider && (
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    API Key
                                </label>
                                <input
                                    type="password"
                                    value={formData.apiKey}
                                    onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                                    className="w-full rounded-lg border border-gray-300 py-2 px-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                                    placeholder="Enter API key"
                                />
                            </div>
                        )}
                    </div>

                    <div className="mt-6 flex justify-end space-x-3">
                        <button
                            onClick={onClose}
                            className="px-4 py-2 text-gray-700 hover:text-gray-900"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={() => onAdd(formData)}
                            className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600"
                            disabled={!formData.type || !formData.provider}
                        >
                            Add Resource
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
