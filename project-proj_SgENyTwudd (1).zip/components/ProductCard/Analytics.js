function Analytics({ metrics }) {
    return (
        <div className="space-y-6">
            {/* Traffic Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <TrafficVisualization 
                    data={{
                        totalVisitors: metrics.users,
                        dates: metrics.userGrowth.labels,
                        organicTraffic: metrics.userGrowth.data,
                        paidTraffic: metrics.userGrowth.data.map(val => val * 0.3), // Simulated paid traffic
                        currentOrganic: metrics.users,
                        currentPaid: Math.round(metrics.users * 0.3),
                        organicChange: metrics.usersTrend,
                        paidChange: metrics.usersTrend,
                        bounceRate: metrics.engagement.bounceRate,
                        bounceRateChange: metrics.engagement.bounceTrend,
                        avgSession: metrics.engagement.averageSession,
                        sessionChange: metrics.engagement.sessionTrend
                    }}
                />
                
                <TrafficSourceChart 
                    data={{
                        direct: metrics.traffic.direct,
                        organic: metrics.traffic.organic,
                        referral: metrics.traffic.referral,
                        social: metrics.traffic.social,
                        total: metrics.traffic.total
                    }}
                />
            </div>

            {/* Engagement Metrics */}
            <EngagementMetrics 
                data={{
                    dates: metrics.engagement.dates,
                    activeUsers: metrics.engagement.activeUsers,
                    sessionDuration: metrics.engagement.sessionDuration,
                    averageSession: metrics.engagement.averageSession,
                    sessionTrend: metrics.engagement.sessionTrend,
                    bounceRate: metrics.engagement.bounceRate,
                    bounceTrend: metrics.engagement.bounceTrend,
                    retention: metrics.engagement.retention,
                    retentionTrend: metrics.engagement.retentionTrend
                }}
            />
        </div>
    );
}
