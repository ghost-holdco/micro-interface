function InteractiveEngagementCard({ title, value, trend, icon, inverseTrend = false, details }) {
    const [isExpanded, setIsExpanded] = React.useState(false);
    const cardRef = React.useRef(null);

    const handleExpandClick = (e) => {
        e.stopPropagation();
        setIsExpanded(!isExpanded);
    };

    return (
        <div className="relative">
            <div 
                ref={cardRef}
                className="bg-gray-50 rounded-lg p-4 border border-gray-100 hover:border-primary-500/50 transition-all duration-200"
            >
                <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-600">{title}</span>
                        {details && (
                            <button 
                                onClick={handleExpandClick}
                                className="text-gray-400 hover:text-gray-600"
                            >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
                                          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </button>
                        )}
                    </div>
                    <span className="text-lg">{icon}</span>
                </div>
                <div className="text-2xl font-bold text-gray-900">{value}</div>
                <div className={`text-sm font-medium ${
                    inverseTrend ? 
                        (trend < 0 ? 'text-emerald-600' : 'text-rose-600') :
                        (trend > 0 ? 'text-emerald-600' : 'text-rose-600')
                } flex items-center mt-1`}>
                    {trend > 0 ? '↑' : '↓'}{Math.abs(trend)}%
                    <span className="text-gray-500 ml-1">vs last period</span>
                </div>
            </div>

            {/* Expanded Details Popover */}
            {isExpanded && details && (
                <div className="absolute top-full left-0 right-0 z-10 mt-2">
                    <MetricDetails metric={details} />
                </div>
            )}
        </div>
    );
}
