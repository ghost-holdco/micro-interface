function MetricDetails({ metric }) {
    return (
        <div className="p-4 bg-white rounded-lg shadow-lg border border-gray-200 max-w-md">
            <div className="flex justify-between items-start mb-4">
                <h3 className="text-lg font-semibold text-gray-900">{metric.title} Details</h3>
                <span className="text-2xl">{metric.icon}</span>
            </div>
            
            {/* Historical Data */}
            <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-600 mb-2">Historical Trend</h4>
                <div className="h-32">
                    <MetricHistoryChart data={metric.history} />
                </div>
            </div>

            {/* Breakdown */}
            <div className="space-y-2">
                {metric.breakdown?.map((item, index) => (
                    <div key={index} className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">{item.label}</span>
                        <span className="text-sm font-medium text-gray-900">{item.value}</span>
                    </div>
                ))}
            </div>

            {/* Additional Info */}
            {metric.additionalInfo && (
                <div className="mt-4 pt-4 border-t border-gray-100">
                    <h4 className="text-sm font-medium text-gray-600 mb-2">Additional Information</h4>
                    <p className="text-sm text-gray-500">{metric.additionalInfo}</p>
                </div>
            )}
        </div>
    );
}

function MetricHistoryChart({ data }) {
    const [chartInstance, setChartInstance] = React.useState(null);

    React.useEffect(() => {
        try {
            const ctx = document.getElementById('metricHistory').getContext('2d');
            if (chartInstance) {
                chartInstance.destroy();
            }

            const gradient = ctx.createLinearGradient(0, 0, 0, 160);
            gradient.addColorStop(0, 'rgba(99, 102, 241, 0.2)');
            gradient.addColorStop(1, 'rgba(99, 102, 241, 0)');

            const newChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels,
                    datasets: [{
                        data: data.values,
                        borderColor: '#6366F1',
                        backgroundColor: gradient,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                display: false
                            }
                        },
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            setChartInstance(newChart);
        } catch (error) {
            reportError(error);
        }
    }, [data]);

    return (
        <canvas id="metricHistory"></canvas>
    );
}
