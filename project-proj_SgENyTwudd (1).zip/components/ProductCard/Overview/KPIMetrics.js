function KPIMetrics({ metrics }) {
    return (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <MetricCard
                title="Monthly Recurring Revenue"
                value={`$${metrics.revenue.toLocaleString()}`}
                trend={metrics.revenueTrend}
                icon="💰"
                description="Monthly recurring revenue from all subscriptions"
                previousValue={`$${(metrics.revenue - (metrics.revenue * metrics.revenueTrend / 100)).toLocaleString()}`}
            />
            <MetricCard
                title="Total Users"
                value={metrics.users.toLocaleString()}
                trend={metrics.usersTrend}
                icon="👥"
                description="Total active users across all plans"
                previousValue={(metrics.users - (metrics.users * metrics.usersTrend / 100)).toLocaleString()}
            />
            <MetricCard
                title="New Users Growth Rate"
                value={`${metrics.usersTrend}%`}
                trend={metrics.usersTrend}
                icon="📈"
                description="Month-over-month user growth rate"
                chart={metrics.userGrowth?.data}
            />
            <MetricCard
                title="Platform Monitoring"
                value={`${metrics.uptime}%`}
                icon="🔍"
                description="Overall platform health status"
                status={metrics.uptime >= 99.9 ? 'success' : metrics.uptime >= 99 ? 'warning' : 'error'}
            />
        </div>
    );
}

function MetricCard({ title, value, trend, icon, description, previousValue, chart, status }) {
    return (
        <div className="bg-white rounded-xl p-4 border border-gray-200 hover:border-primary-500/50 transition-colors duration-200 shadow-sm">
            <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-600">{title}</span>
                <span className="text-lg">{icon}</span>
            </div>
            <div className="flex items-baseline space-x-2 mb-1">
                <span className="text-2xl font-bold text-gray-900">{value}</span>
                {trend && (
                    <span className={`text-sm font-medium ${
                        trend > 0 ? 'text-emerald-600' : 'text-rose-600'
                    }`}>
                        {trend > 0 ? '↑' : '↓'}{Math.abs(trend)}%
                    </span>
                )}
            </div>
            {description && (
                <p className="text-xs text-gray-500">{description}</p>
            )}
            {previousValue && (
                <div className="mt-2 text-xs text-gray-500">
                    Previous: {previousValue}
                </div>
            )}
            {chart && (
                <div className="mt-2 h-8">
                    <SparklineChart data={chart} color={trend > 0 ? '#059669' : '#DC2626'} />
                </div>
            )}
            {status && (
                <div className="mt-2 flex items-center space-x-1">
                    <div className={`w-1.5 h-1.5 rounded-full ${
                        status === 'success' ? 'bg-emerald-500' :
                        status === 'warning' ? 'bg-amber-500' :
                        'bg-rose-500'
                    }`} />
                    <span className="text-xs text-gray-600">
                        {status === 'success' ? 'Healthy' :
                         status === 'warning' ? 'Warning' :
                         'Critical'}
                    </span>
                </div>
            )}
        </div>
    );
}

function SparklineChart({ data, color }) {
    const [chartInstance, setChartInstance] = React.useState(null);

    React.useEffect(() => {
        try {
            const ctx = document.getElementById('sparkline').getContext('2d');
            if (chartInstance) {
                chartInstance.destroy();
            }

            const newChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.map((_, i) => i),
                    datasets: [{
                        data: data,
                        borderColor: color,
                        borderWidth: 2,
                        fill: false,
                        pointRadius: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        x: {
                            display: false
                        },
                        y: {
                            display: false
                        }
                    }
                }
            });

            setChartInstance(newChart);
        } catch (error) {
            reportError(error);
        }
    }, [data, color]);

    return (
        <canvas id="sparkline"></canvas>
    );
}
