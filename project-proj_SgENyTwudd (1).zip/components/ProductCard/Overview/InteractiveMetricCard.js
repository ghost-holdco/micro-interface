function InteractiveMetricCard({ title, value, trend, icon, description, previousValue, chart, status, details }) {
    const [isExpanded, setIsExpanded] = React.useState(false);
    const [isHovered, setIsHovered] = React.useState(false);
    const cardRef = React.useRef(null);

    const handleClick = () => {
        if (details) {
            setIsExpanded(!isExpanded);
        }
    };

    return (
        <div
            ref={cardRef}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            onClick={handleClick}
            className={`relative bg-white rounded-xl p-4 border border-gray-200 transition-all duration-200
                ${details ? 'cursor-pointer' : ''}
                ${isHovered ? 'shadow-md border-primary-500/50' : 'shadow-sm'}
            `}
        >
            {/* Card Header */}
            <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-600">{title}</span>
                    {details && (
                        <button 
                            onClick={(e) => {
                                e.stopPropagation();
                                setIsExpanded(!isExpanded);
                            }}
                            className="text-gray-400 hover:text-gray-600"
                        >
                            <svg className={`w-4 h-4 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} 
                                 fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                    )}
                </div>
                <span className="text-lg">{icon}</span>
            </div>

            {/* Main Value */}
            <div className="flex items-baseline space-x-2 mb-1">
                <span className="text-2xl font-bold text-gray-900">{value}</span>
                {trend && (
                    <span className={`text-sm font-medium ${
                        trend > 0 ? 'text-emerald-600' : 'text-rose-600'
                    }`}>
                        {trend > 0 ? '↑' : '↓'}{Math.abs(trend)}%
                    </span>
                )}
            </div>

            {/* Description */}
            {description && (
                <p className="text-xs text-gray-500">{description}</p>
            )}

            {/* Previous Value */}
            {previousValue && (
                <div className="mt-2 text-xs text-gray-500">
                    Previous: {previousValue}
                </div>
            )}

            {/* Sparkline Chart */}
            {chart && (
                <div className="mt-2 h-8">
                    <SparklineChart data={chart} color={trend > 0 ? '#059669' : '#DC2626'} />
                </div>
            )}

            {/* Status Indicator */}
            {status && (
                <div className="mt-2 flex items-center space-x-1">
                    <div className={`w-1.5 h-1.5 rounded-full ${
                        status === 'success' ? 'bg-emerald-500' :
                        status === 'warning' ? 'bg-amber-500' :
                        'bg-rose-500'
                    }`} />
                    <span className="text-xs text-gray-600">
                        {status === 'success' ? 'Healthy' :
                         status === 'warning' ? 'Warning' :
                         'Critical'}
                    </span>
                </div>
            )}

            {/* Expanded Details */}
            {isExpanded && details && (
                <div className="absolute top-full left-0 right-0 z-10 mt-2">
                    <MetricDetails metric={details} />
                </div>
            )}
        </div>
    );
}
