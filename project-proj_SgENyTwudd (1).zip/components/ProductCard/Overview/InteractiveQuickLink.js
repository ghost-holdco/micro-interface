function InteractiveQuickLink({ title, icon, href, metrics, details }) {
    const [showDetails, setShowDetails] = React.useState(false);
    
    return (
        <div className="relative group">
            <a 
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="block bg-white rounded-xl p-4 border border-gray-200 hover:border-primary-500/50 transition-all duration-200 hover:shadow-sm"
            >
                <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-gray-700 group-hover:text-gray-900">
                        {title}
                    </span>
                    <span className="text-lg group-hover:scale-110 transition-transform duration-200">
                        {icon}
                    </span>
                </div>
                <div className="flex items-center justify-between">
                    {metrics.map((metric, index) => (
                        <div key={index} className="text-center">
                            <div className="text-sm font-semibold text-gray-900">
                                {metric.value}
                            </div>
                            <div className="text-xs text-gray-500">
                                {metric.label}
                            </div>
                        </div>
                    ))}
                </div>
            </a>

            {details && (
                <button
                    onClick={() => setShowDetails(!showDetails)}
                    className="absolute top-2 right-2 p-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
                >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
                              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </button>
            )}

            {showDetails && details && (
                <div className="absolute top-full left-0 right-0 z-10 mt-2">
                    <MetricDetails metric={details} />
                </div>
            )}
        </div>
    );
}
