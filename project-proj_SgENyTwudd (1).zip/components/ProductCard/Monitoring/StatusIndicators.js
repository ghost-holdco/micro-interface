function StatusIndicator({ status }) {
    const statusConfig = {
        healthy: {
            color: 'bg-green-500',
            pulse: 'animate-pulse',
            ring: 'ring-green-100'
        },
        warning: {
            color: 'bg-yellow-500',
            pulse: '',
            ring: 'ring-yellow-100'
        },
        error: {
            color: 'bg-red-500',
            pulse: 'animate-ping',
            ring: 'ring-red-100'
        }
    };

    const config = statusConfig[status];

    return (
        <div className={`relative rounded-full h-4 w-4 ${config.color} ring-4 ${config.ring}`}>
            {config.pulse && (
                <span className={`absolute inline-flex h-full w-full rounded-full ${config.color} opacity-75 ${config.pulse}`}></span>
            )}
        </div>
    );
}

function StatusBadge({ status }) {
    const statusConfig = {
        healthy: {
            bg: 'bg-green-100',
            text: 'text-green-700',
            label: 'Healthy'
        },
        warning: {
            bg: 'bg-yellow-100',
            text: 'text-yellow-700',
            label: 'Warning'
        },
        error: {
            bg: 'bg-red-100',
            text: 'text-red-700',
            label: 'Error'
        }
    };

    const config = statusConfig[status];

    return (
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${config.bg} ${config.text}`}>
            {config.label}
        </span>
    );
}
