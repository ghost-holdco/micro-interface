function HealthStatusGrid({ products }) {
    const [selectedCategory, setSelectedCategory] = React.useState('all');
    const [timeRange, setTimeRange] = React.useState('24h');

    const categories = [
        { id: 'all', name: 'All Systems', icon: '🎯' },
        { id: 'infrastructure', name: 'Infrastructure', icon: '🏗️' },
        { id: 'security', name: 'Security', icon: '🔒' },
        { id: 'performance', name: 'Performance', icon: '⚡' },
        { id: 'database', name: 'Database', icon: '💾' },
        { id: 'integrations', name: 'Integrations', icon: '🔌' }
    ];

    const timeRanges = [
        { id: '24h', name: 'Last 24 hours' },
        { id: '7d', name: 'Last 7 days' },
        { id: '30d', name: 'Last 30 days' }
    ];

    return (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            {/* Header */}
            <div className="p-6 border-b border-gray-200">
                <div className="flex justify-between items-center">
                    <div>
                        <h3 className="text-lg font-semibold text-gray-900">System Health</h3>
                        <p className="text-sm text-gray-500">
                            Real-time monitoring status
                        </p>
                    </div>
                    <div className="flex items-center space-x-4">
                        <select
                            value={timeRange}
                            onChange={(e) => setTimeRange(e.target.value)}
                            className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700"
                        >
                            {timeRanges.map(range => (
                                <option key={range.id} value={range.id}>{range.name}</option>
                            ))}
                        </select>
                    </div>
                </div>

                {/* Category Tabs */}
                <div className="mt-6 border-b border-gray-200">
                    <div className="flex space-x-6 overflow-x-auto pb-2">
                        {categories.map(category => (
                            <button
                                key={category.id}
                                onClick={() => setSelectedCategory(category.id)}
                                className={`flex items-center space-x-2 pb-3 px-1 text-sm font-medium transition-colors duration-200
                                    ${selectedCategory === category.id 
                                        ? 'text-primary-600 border-b-2 border-primary-600' 
                                        : 'text-gray-500 hover:text-gray-700'}`}
                            >
                                <span>{category.icon}</span>
                                <span>{category.name}</span>
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* Content */}
            <div className="p-6">
                <div className="grid grid-cols-1 gap-6">
                    {products.map(product => (
                        <ProductHealthCard 
                            key={product.objectId}
                            product={product}
                            selectedCategory={selectedCategory}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
}

function ProductHealthCard({ product, selectedCategory }) {
    const getMetrics = () => {
        switch (selectedCategory) {
            case 'infrastructure':
                return [
                    {
                        label: "Server Uptime",
                        value: `${product.objectData.metrics.uptime}%`,
                        status: product.objectData.metrics.uptimeStatus,
                        icon: "⚡",
                        details: [
                            { label: "Last Downtime", value: "2 days ago" },
                            { label: "Duration", value: "3m 45s" },
                            { label: "Region", value: "us-east-1" }
                        ]
                    },
                    {
                        label: "Response Time",
                        value: `${product.objectData.metrics.responseTime}ms`,
                        status: product.objectData.metrics.responseStatus,
                        icon: "⏱️",
                        details: [
                            { label: "p95", value: "280ms" },
                            { label: "p99", value: "350ms" },
                            { label: "Avg", value: "145ms" }
                        ]
                    }
                ];
            case 'security':
                return [
                    {
                        label: "SSL Certificate",
                        value: product.objectData.metrics.sslStatus,
                        status: product.objectData.metrics.sslHealth,
                        icon: "🔒",
                        details: [
                            { label: "Expires", value: "87 days" },
                            { label: "Provider", value: "Let's Encrypt" },
                            { label: "Type", value: "EV SSL" }
                        ]
                    },
                    {
                        label: "Security Scan",
                        value: "No Issues",
                        status: "healthy",
                        icon: "🛡️",
                        details: [
                            { label: "Last Scan", value: "2 hours ago" },
                            { label: "Vulnerabilities", value: "0" },
                            { label: "WAF Status", value: "Active" }
                        ]
                    }
                ];
            case 'database':
                return [
                    {
                        label: "Database",
                        value: product.objectData.metrics.databaseStatus,
                        status: product.objectData.metrics.databaseHealth,
                        icon: "💾",
                        details: [
                            { label: "Connections", value: "45/100" },
                            { label: "Load", value: "32%" },
                            { label: "Storage", value: "65% used" }
                        ]
                    },
                    {
                        label: "Cache",
                        value: product.objectData.metrics.cacheStatus,
                        status: product.objectData.metrics.cacheHealth,
                        icon: "⚡",
                        details: [
                            { label: "Hit Rate", value: "94.5%" },
                            { label: "Memory", value: "78%" },
                            { label: "Keys", value: "125K" }
                        ]
                    }
                ];
            case 'performance':
                return [
                    {
                        label: "CDN",
                        value: product.objectData.metrics.cdnStatus,
                        status: product.objectData.metrics.cdnHealth,
                        icon: "🌐",
                        details: [
                            { label: "Cache Hit", value: "92.3%" },
                            { label: "Bandwidth", value: "1.2TB" },
                            { label: "Requests", value: "15M/day" }
                        ]
                    },
                    {
                        label: "Web Vitals",
                        value: "Good",
                        status: "healthy",
                        icon: "📊",
                        details: [
                            { label: "LCP", value: "2.1s" },
                            { label: "FID", value: "12ms" },
                            { label: "CLS", value: "0.05" }
                        ]
                    }
                ];
            default:
                return [
                    {
                        label: "Overall Health",
                        value: "98%",
                        status: "healthy",
                        icon: "💚",
                        details: [
                            { label: "Components", value: "15/15 healthy" },
                            { label: "Last Issue", value: "3 days ago" },
                            { label: "MTTR", value: "45 minutes" }
                        ]
                    }
                ];
        }
    };

    return (
        <div className="bg-gray-50 rounded-xl p-8">
            {/* Card Header */}
            <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-xl bg-gray-800 flex items-center justify-center">
                        <span className="text-xl font-semibold text-white">
                            {product.objectData.name.charAt(0)}
                        </span>
                    </div>
                    <div>
                        <h4 className="text-xl font-semibold text-gray-900">{product.objectData.name}</h4>
                        <p className="text-sm text-gray-500">{product.objectData.domain}</p>
                    </div>
                </div>
                <StatusIndicator status={product.objectData.metrics.status} />
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-6">
                {getMetrics().map((metric, index) => (
                    <div key={index} className="bg-white rounded-xl p-6 border border-gray-100">
                        <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center space-x-3">
                                <span className="text-2xl">{metric.icon}</span>
                                <h5 className="text-lg font-medium text-gray-900">{metric.label}</h5>
                            </div>
                            <StatusBadge status={metric.status} />
                        </div>
                        <div className="text-3xl font-bold text-gray-900 mb-6">
                            {metric.value}
                        </div>
                        <div className="space-y-3">
                            {metric.details.map((detail, idx) => (
                                <div key={idx} className="flex justify-between items-center">
                                    <span className="text-sm text-gray-500">{detail.label}</span>
                                    <span className="text-sm font-medium text-gray-900">{detail.value}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>

            {/* Actions */}
            <div className="mt-8 pt-6 border-t border-gray-200">
                <div className="flex justify-between items-center">
                    <div className="flex space-x-4">
                        <button className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 hover:text-gray-900 flex items-center space-x-2">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
                                      d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                            </svg>
                            <span>View Logs</span>
                        </button>
                        <button className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 hover:text-gray-900 flex items-center space-x-2">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                            <span>Monitor</span>
                        </button>
                    </div>
                    <button className="px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700">
                        Configure Alerts
                    </button>
                </div>
            </div>
        </div>
    );
}

function StatusIndicator({ status }) {
    const statusConfig = {
        healthy: {
            color: 'bg-green-500',
            pulse: 'animate-pulse',
            ring: 'ring-green-100'
        },
        warning: {
            color: 'bg-yellow-500',
            pulse: '',
            ring: 'ring-yellow-100'
        },
        error: {
            color: 'bg-red-500',
            pulse: 'animate-ping',
            ring: 'ring-red-100'
        }
    };

    const config = statusConfig[status];

    return (
        <div className={`relative rounded-full h-4 w-4 ${config.color} ring-4 ${config.ring}`}>
            {config.pulse && (
                <span className={`absolute inline-flex h-full w-full rounded-full ${config.color} opacity-75 ${config.pulse}`}></span>
            )}
        </div>
    );
}

function StatusBadge({ status }) {
    const statusConfig = {
        healthy: {
            bg: 'bg-green-100',
            text: 'text-green-700',
            label: 'Healthy'
        },
        warning: {
            bg: 'bg-yellow-100',
            text: 'text-yellow-700',
            label: 'Warning'
        },
        error: {
            bg: 'bg-red-100',
            text: 'text-red-700',
            label: 'Error'
        }
    };

    const config = statusConfig[status];

    return (
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${config.bg} ${config.text}`}>
            {config.label}
        </span>
    );
}
