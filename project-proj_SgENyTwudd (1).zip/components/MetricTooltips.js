const metricTooltips = {
    revenue: {
        title: 'Monthly Revenue',
        description: 'Total revenue generated in the current month from all sources including subscriptions, one-time purchases, and add-ons.'
    },
    users: {
        title: 'Active Users',
        description: 'Number of unique users who have interacted with the product in the last 30 days.'
    },
    performance: {
        title: 'Performance Score',
        description: 'Overall performance rating based on response time, uptime, and user experience metrics.'
    },
    uptime: {
        title: 'System Uptime',
        description: 'Percentage of time the system has been operational and accessible over the last 30 days.'
    },
    responseTime: {
        title: 'Response Time',
        description: 'Average time taken to process and respond to user requests.'
    },
    status: {
        healthy: {
            title: 'Healthy',
            description: 'All systems are operating normally with no issues detected.'
        },
        warning: {
            title: 'Warning',
            description: 'Minor issues detected that require attention but are not affecting core functionality.'
        },
        error: {
            title: 'Error',
            description: 'Critical issues detected that are affecting system functionality and require immediate attention.'
        }
    },
    trends: {
        positive: {
            title: 'Positive Trend',
            description: 'Metric has improved compared to the previous period.'
        },
        negative: {
            title: 'Negative Trend',
            description: 'Metric has declined compared to the previous period.'
        }
    }
};

function MetricTooltip({ type, children }) {
    const tooltipContent = metricTooltips[type];
    
    if (!tooltipContent) return children;

    return (
        <Tooltip content={
            <div>
                <div className="font-semibold mb-1">{tooltipContent.title}</div>
                <div className="text-gray-200">{tooltipContent.description}</div>
            </div>
        }>
            {children}
        </Tooltip>
    );
}
