function ProductsOverview({ products, onProductSelect }) {
    const [viewMode, setViewMode] = React.useState('grid');
    const [sortBy, setSortBy] = React.useState('recent');

    const sortedProducts = React.useMemo(() => {
        return [...products].sort((a, b) => {
            switch (sortBy) {
                case 'revenue':
                    return b.objectData.metrics.revenue - a.objectData.metrics.revenue;
                case 'users':
                    return b.objectData.metrics.users - a.objectData.metrics.users;
                case 'performance':
                    return b.objectData.metrics.performance - a.objectData.metrics.performance;
                default: // recent
                    return new Date(b.updatedAt) - new Date(a.updatedAt);
            }
        });
    }, [products, sortBy]);

    return (
        <div data-name="products-overview" className="container mx-auto px-4 py-8">
            <div className="flex flex-col space-y-6">
                {/* Header Section */}
                <div className="flex justify-between items-center">
                    <div>
                        <h2 className="text-2xl font-bold text-white">Your Micro-SaaS Products</h2>
                        <p className="text-gray-400 mt-1">Track and manage your products in one place</p>
                    </div>
                    <div className="flex items-center space-x-4">
                        {/* View Toggle */}
                        <div className="bg-gray-800 rounded-lg p-1">
                            <button
                                onClick={() => setViewMode('grid')}
                                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors duration-200
                                    ${viewMode === 'grid' 
                                        ? 'bg-primary-600 text-white' 
                                        : 'text-gray-400 hover:text-white'}`}
                            >
                                Grid
                            </button>
                            <button
                                onClick={() => setViewMode('list')}
                                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors duration-200
                                    ${viewMode === 'list' 
                                        ? 'bg-primary-600 text-white' 
                                        : 'text-gray-400 hover:text-white'}`}
                            >
                                List
                            </button>
                        </div>
                        {/* Sort Dropdown */}
                        <select
                            value={sortBy}
                            onChange={(e) => setSortBy(e.target.value)}
                            className="bg-gray-800 text-gray-300 rounded-lg px-3 py-2 text-sm font-medium border border-gray-700"
                        >
                            <option value="recent">Most Recent</option>
                            <option value="revenue">Highest Revenue</option>
                            <option value="users">Most Users</option>
                            <option value="performance">Best Performance</option>
                        </select>
                    </div>
                </div>

                {/* Products Grid/List */}
                <div className={viewMode === 'grid' 
                    ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
                    : 'space-y-4'
                }>
                    {sortedProducts.map(product => (
                        <ProductOverviewCard 
                            key={product.objectId}
                            product={product}
                            onClick={() => onProductSelect(product)}
                            viewMode={viewMode}
                        />
                    ))}
                </div>

                {/* Empty State */}
                {products.length === 0 && (
                    <div className="text-center py-12">
                        <div className="text-6xl mb-4">🚀</div>
                        <h3 className="text-xl font-semibold text-white mb-2">No products yet</h3>
                        <p className="text-gray-400 mb-6">Start by adding your first Micro-SaaS product</p>
                        <AddProductButton />
                    </div>
                )}
            </div>
        </div>
    );
}

function ProductOverviewCard({ product, onClick, viewMode }) {
    const metrics = product.objectData.metrics;

    if (viewMode === 'list') {
        return (
            <div 
                data-name={`product-overview-${product.objectId}`}
                onClick={onClick}
                className="glass-card rounded-xl p-4 cursor-pointer transition-all duration-300 hover:transform hover:translate-x-2"
            >
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
                            <span className="text-lg font-semibold text-white">
                                {product.objectData.name.charAt(0)}
                            </span>
                        </div>
                        <div>
                            <h3 className="text-lg font-semibold text-white">{product.objectData.name}</h3>
                            <p className="text-sm text-gray-400">{product.objectData.domain}</p>
                        </div>
                    </div>
                    <div className="flex items-center space-x-6">
                        <div className="text-right">
                            <p className="text-sm text-gray-400">Monthly Revenue</p>
                            <p className="text-lg font-semibold text-white">${metrics.revenue.toLocaleString()}</p>
                        </div>
                        <div className="text-right">
                            <p className="text-sm text-gray-400">Active Users</p>
                            <p className="text-lg font-semibold text-white">{metrics.users.toLocaleString()}</p>
                        </div>
                        <div className={`w-3 h-3 rounded-full ${getStatusColor(metrics.status)}`} />
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div 
            data-name={`product-overview-${product.objectId}`}
            onClick={onClick}
            className="glass-card rounded-xl p-6 cursor-pointer transition-all duration-300 hover:transform hover:scale-105"
        >
            <div className="flex justify-between items-start mb-4">
                <div>
                    <div className="w-12 h-12 rounded-lg bg-gray-800 flex items-center justify-center mb-4">
                        <span className="text-xl font-semibold text-white">
                            {product.objectData.name.charAt(0)}
                        </span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-1">{product.objectData.name}</h3>
                    <p className="text-sm text-gray-400">{product.objectData.domain}</p>
                </div>
                <div className={`w-3 h-3 rounded-full ${getStatusColor(metrics.status)}`} />
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="glass-card p-3 rounded-lg">
                    <p className="text-sm text-gray-400">Monthly Users</p>
                    <p className="text-lg font-bold text-white">{metrics.users.toLocaleString()}</p>
                </div>
                <div className="glass-card p-3 rounded-lg">
                    <p className="text-sm text-gray-400">Monthly Revenue</p>
                    <p className="text-lg font-bold text-white">${metrics.revenue.toLocaleString()}</p>
                </div>
            </div>

            <div className="border-t border-gray-700 pt-4">
                <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-400">Tech Stack:</span>
                    <div className="flex space-x-2">
                        {product.objectData.hosting && (
                            <span className="px-2 py-1 rounded bg-gray-800 text-xs text-gray-300">
                                {product.objectData.hosting}
                            </span>
                        )}
                        {product.objectData.database && (
                            <span className="px-2 py-1 rounded bg-gray-800 text-xs text-gray-300">
                                {product.objectData.database}
                            </span>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

function getStatusColor(status) {
    switch (status) {
        case 'healthy':
            return 'bg-green-400';
        case 'warning':
            return 'bg-yellow-400';
        case 'error':
            return 'bg-red-400';
        default:
            return 'bg-gray-400';
    }
}
