function AddProductModal({ isOpen, onClose, children }) {
    if (!isOpen) return null;

    return (
        <div data-name="modal-overlay" 
             className="fixed inset-0 bg-gray-900 bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50 transition-opacity duration-300">
            <div data-name="modal-container" 
                 className="relative w-full max-w-4xl mx-4 opacity-0 transform translate-y-4 transition-all duration-300"
                 style={{ animation: 'modalFadeIn 0.3s ease-out forwards' }}>
                <div data-name="modal-content" 
                     className="bg-white rounded-2xl shadow-xl overflow-hidden">
                    <button
                        data-name="close-modal"
                        onClick={onClose}
                        className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors duration-200"
                        aria-label="Close modal"
                    >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                    {children}
                </div>
            </div>

            <style>
                {`
                    @keyframes modalFadeIn {
                        from {
                            opacity: 0;
                            transform: translateY(1rem);
                        }
                        to {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }
                `}
            </style>
        </div>
    );
}
