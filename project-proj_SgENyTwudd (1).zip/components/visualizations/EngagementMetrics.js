function EngagementMetrics({ data }) {
    const [chartData, setChartData] = React.useState(null);

    React.useEffect(() => {
        try {
            const ctx = document.getElementById('engagementChart').getContext('2d');
            if (chartData) chartData.destroy();

            const gradient = ctx.createLinearGradient(0, 0, 0, 400);
            gradient.addColorStop(0, 'rgba(99, 102, 241, 0.1)');
            gradient.addColorStop(1, 'rgba(99, 102, 241, 0.0)');

            const newChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.dates,
                    datasets: [{
                        label: 'Active Users',
                        data: data.activeUsers,
                        borderColor: '#6366F1',
                        backgroundColor: gradient,
                        fill: true,
                        tension: 0.4,
                        borderWidth: 2,
                        pointRadius: 4,
                        pointBackgroundColor: '#FFFFFF',
                        pointBorderColor: '#6366F1',
                        pointHoverRadius: 6
                    }, {
                        label: 'Session Duration',
                        data: data.sessionDuration,
                        borderColor: '#10B981',
                        backgroundColor: 'transparent',
                        borderWidth: 2,
                        tension: 0.4,
                        pointRadius: 4,
                        pointBackgroundColor: '#FFFFFF',
                        pointBorderColor: '#10B981',
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                            align: 'end',
                            labels: {
                                boxWidth: 8,
                                usePointStyle: true,
                                pointStyle: 'circle',
                                padding: 20,
                                color: '#4B5563',
                                font: {
                                    family: 'Inter',
                                    size: 12
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(255, 255, 255, 0.9)',
                            titleColor: '#111827',
                            bodyColor: '#4B5563',
                            borderColor: '#E5E7EB',
                            borderWidth: 1,
                            padding: 12,
                            cornerRadius: 8,
                            displayColors: true,
                            boxPadding: 6,
                            usePointStyle: true
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                color: '#9CA3AF',
                                font: {
                                    family: 'Inter',
                                    size: 12
                                }
                            }
                        },
                        y: {
                            grid: {
                                color: '#F3F4F6'
                            },
                            ticks: {
                                color: '#9CA3AF',
                                font: {
                                    family: 'Inter',
                                    size: 12
                                }
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    }
                }
            });
            setChartData(newChart);
        } catch (error) {
            reportError(error);
        }
    }, [data]);

    return (
        <div data-name="engagement-metrics" className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h3 className="text-lg font-semibold text-gray-900">User Engagement</h3>
                    <p className="text-sm text-gray-500 mt-1">User activity and session metrics</p>
                </div>
                <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700">
                    <option>Last 7 days</option>
                    <option>Last 30 days</option>
                    <option>Last 90 days</option>
                </select>
            </div>

            <div className="relative h-80">
                <canvas id="engagementChart"></canvas>
            </div>

            <div className="grid grid-cols-3 gap-6 mt-6">
                <MetricCard
                    label="Avg. Session"
                    value={`${data.averageSession}m`}
                    trend={data.sessionTrend}
                    icon="⏱️"
                />
                <MetricCard
                    label="Bounce Rate"
                    value={`${data.bounceRate}%`}
                    trend={data.bounceTrend}
                    inverseTrend={true}
                    icon="↩️"
                />
                <MetricCard
                    label="Retention"
                    value={`${data.retention}%`}
                    trend={data.retentionTrend}
                    icon="🎯"
                />
            </div>
        </div>
    );
}

function MetricCard({ label, value, trend, inverseTrend = false, icon }) {
    const isPositive = inverseTrend ? trend < 0 : trend > 0;
    const trendColor = isPositive ? 'text-green-600' : 'text-red-600';
    const trendIcon = isPositive ? '↑' : '↓';

    return (
        <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
            <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">{label}</span>
                <span className="text-lg">{icon}</span>
            </div>
            <div className="text-2xl font-semibold text-gray-900">{value}</div>
            <div className={`text-sm font-medium ${trendColor} flex items-center mt-1`}>
                {trendIcon} {Math.abs(trend)}%
                <span className="text-gray-500 ml-1">vs last period</span>
            </div>
        </div>
    );
}
