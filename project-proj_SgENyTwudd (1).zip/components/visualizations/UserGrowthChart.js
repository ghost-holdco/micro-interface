function UserGrowthChart({ data }) {
    const [chartInstance, setChartInstance] = React.useState(null);

    React.useEffect(() => {
        try {
            const ctx = document.getElementById('userGrowthChart').getContext('2d');
            if (chartInstance) {
                chartInstance.destroy();
            }

            const newChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.periods,
                    datasets: [{
                        label: 'Active Users',
                        data: data.users,
                        borderColor: '#6366F1',
                        backgroundColor: 'rgba(99, 102, 241, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#E5E7EB'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });

            setChartInstance(newChart);
        } catch (error) {
            reportError(error);
        }
    }, [data]);

    return (
        <div className="h-64">
            <canvas id="userGrowthChart"></canvas>
        </div>
    );
}
