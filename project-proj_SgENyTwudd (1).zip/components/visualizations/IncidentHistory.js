function IncidentHistory({ incidents }) {
    if (!incidents || incidents.length === 0) {
        return (
            <div className="text-center py-8 text-gray-500">
                No incidents reported
            </div>
        );
    }

    return (
        <div className="space-y-4">
            {incidents.map((incident, index) => (
                <div 
                    key={index}
                    className="flex items-start space-x-4 p-4 bg-white rounded-lg border border-gray-100"
                >
                    <div className="flex-shrink-0">
                        <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
                            <span className="text-red-600 text-lg">⚠️</span>
                        </div>
                    </div>
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                            <p className="text-sm font-medium text-gray-900">
                                {incident.type}
                            </p>
                            <span className="text-sm text-gray-500">
                                {incident.duration}
                            </span>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                            Affected: {incident.affected}
                        </p>
                        <p className="text-xs text-gray-400 mt-1">
                            {new Date(incident.date).toLocaleDateString()}
                        </p>
                    </div>
                </div>
            ))}
        </div>
    );
}
