function TrafficAnalysis({ metrics }) {
    const [timeRange, setTimeRange] = React.useState('7d');
    const [chartInstance, setChartInstance] = React.useState(null);

    React.useEffect(() => {
        try {
            const ctx = document.getElementById('trafficAnalysisChart').getContext('2d');
            if (chartInstance) {
                chartInstance.destroy();
            }

            const gradient = ctx.createLinearGradient(0, 0, 0, 400);
            gradient.addColorStop(0, 'rgba(99, 102, 241, 0.1)');
            gradient.addColorStop(1, 'rgba(99, 102, 241, 0)');

            const newChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: metrics.trafficTrend.periods,
                    datasets: [
                        {
                            label: 'Organic Traffic',
                            data: metrics.trafficTrend.organic,
                            borderColor: '#6366F1',
                            backgroundColor: gradient,
                            fill: true,
                            tension: 0.4
                        },
                        {
                            label: 'Paid Traffic',
                            data: metrics.trafficTrend.paid,
                            borderColor: '#10B981',
                            backgroundColor: 'transparent',
                            tension: 0.4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                usePointStyle: true,
                                padding: 20,
                                font: {
                                    family: 'Inter'
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(255, 255, 255, 0.9)',
                            titleColor: '#1F2937',
                            bodyColor: '#4B5563',
                            borderColor: '#E5E7EB',
                            borderWidth: 1,
                            padding: 12,
                            cornerRadius: 8,
                            usePointStyle: true,
                            callbacks: {
                                label: (context) => {
                                    return `${context.dataset.label}: ${context.parsed.y.toLocaleString()} visitors`;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                font: {
                                    family: 'Inter'
                                }
                            }
                        },
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#F3F4F6'
                            },
                            ticks: {
                                font: {
                                    family: 'Inter'
                                },
                                callback: (value) => value.toLocaleString()
                            }
                        }
                    }
                }
            });

            setChartInstance(newChart);
        } catch (error) {
            reportError(error);
        }
    }, [metrics, timeRange]);

    return (
        <div className="space-y-6">
            {/* Header and Controls */}
            <div className="flex justify-between items-center">
                <div>
                    <h3 className="text-lg font-semibold text-gray-900">Traffic Analysis</h3>
                    <p className="text-sm text-gray-500">
                        Total Visitors: {(metrics.organicTraffic + metrics.paidTraffic).toLocaleString()}
                    </p>
                </div>
                <select
                    value={timeRange}
                    onChange={(e) => setTimeRange(e.target.value)}
                    className="text-sm border border-gray-200 rounded-lg px-3 py-2"
                >
                    <option value="7d">Last 7 days</option>
                    <option value="30d">Last 30 days</option>
                    <option value="90d">Last 90 days</option>
                </select>
            </div>

            {/* Main Chart */}
            <div className="h-80">
                <canvas id="trafficAnalysisChart"></canvas>
            </div>

            {/* Traffic Breakdown */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <TrafficBreakdownCard
                    title="Traffic Sources"
                    data={metrics.trafficSources}
                    icon="🌐"
                />
                <TrafficBreakdownCard
                    title="Geographic Data"
                    data={metrics.geographicData}
                    icon="🌍"
                />
                <TrafficBreakdownCard
                    title="Device Usage"
                    data={metrics.deviceData}
                    icon="📱"
                />
            </div>

            {/* Additional Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <MetricTile
                    label="Avg. Session Duration"
                    value="4m 32s"
                    trend={+5.2}
                    icon="⏱️"
                />
                <MetricTile
                    label="Bounce Rate"
                    value="42.3%"
                    trend={-2.1}
                    icon="↩️"
                    inverseTrend
                />
                <MetricTile
                    label="Pages / Session"
                    value="3.8"
                    trend={+1.8}
                    icon="📄"
                />
                <MetricTile
                    label="New Users"
                    value="64.7%"
                    trend={+3.4}
                    icon="👥"
                />
            </div>
        </div>
    );
}

function TrafficBreakdownCard({ title, data, icon }) {
    return (
        <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-4">
                <h4 className="text-sm font-medium text-gray-900">{title}</h4>
                <span className="text-lg">{icon}</span>
            </div>
            <div className="space-y-3">
                {Object.entries(data).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 capitalize">{key}</span>
                        <div className="flex items-center space-x-2">
                            <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                                <div
                                    className="h-full bg-primary-600 rounded-full"
                                    style={{ width: `${value}%` }}
                                />
                            </div>
                            <span className="text-sm font-medium text-gray-900">{value}%</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

function MetricTile({ label, value, trend, icon, inverseTrend = false }) {
    const isPositive = inverseTrend ? trend < 0 : trend > 0;
    const trendColor = isPositive ? 'text-green-600' : 'text-red-600';
    const trendIcon = isPositive ? '↑' : '↓';

    return (
        <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">{label}</span>
                <span className="text-lg">{icon}</span>
            </div>
            <div className="text-2xl font-semibold text-gray-900">{value}</div>
            <div className={`text-sm font-medium ${trendColor} flex items-center mt-1`}>
                {trendIcon} {Math.abs(trend)}%
                <span className="text-gray-500 ml-1">vs last period</span>
            </div>
        </div>
    );
}
