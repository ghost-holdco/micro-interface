function TrafficVisualization({ data }) {
    const [chartType, setChartType] = React.useState('area');
    const [timeRange, setTimeRange] = React.useState('30d');
    const [chartInstance, setChartInstance] = React.useState(null);

    React.useEffect(() => {
        if (chartInstance) {
            chartInstance.destroy();
        }

        const ctx = document.getElementById('trafficChart').getContext('2d');
        const gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, 'rgba(99, 102, 241, 0.2)');
        gradient.addColorStop(1, 'rgba(99, 102, 241, 0.0)');

        const newChart = new Chart(ctx, {
            type: chartType === 'area' ? 'line' : chartType,
            data: {
                labels: data.dates,
                datasets: [
                    {
                        label: 'Organic Traffic',
                        data: data.organicTraffic,
                        borderColor: '#6366F1',
                        backgroundColor: chartType === 'area' ? gradient : '#6366F1',
                        fill: chartType === 'area',
                        tension: 0.4
                    },
                    {
                        label: 'Paid Traffic',
                        data: data.paidTraffic,
                        borderColor: '#10B981',
                        backgroundColor: chartType === 'area' ? 'rgba(16, 185, 129, 0.1)' : '#10B981',
                        fill: chartType === 'area',
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            font: {
                                family: 'Inter'
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(255, 255, 255, 0.9)',
                        titleColor: '#1F2937',
                        bodyColor: '#4B5563',
                        borderColor: '#E5E7EB',
                        borderWidth: 1,
                        padding: 12,
                        cornerRadius: 8,
                        usePointStyle: true,
                        callbacks: {
                            label: (context) => {
                                return `${context.dataset.label}: ${context.parsed.y.toLocaleString()}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                family: 'Inter'
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#F3F4F6'
                        },
                        ticks: {
                            font: {
                                family: 'Inter'
                            },
                            callback: (value) => value.toLocaleString()
                        }
                    }
                }
            }
        });

        setChartInstance(newChart);

        return () => {
            if (newChart) {
                newChart.destroy();
            }
        };
    }, [data, chartType]);

    return (
        <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h3 className="text-lg font-semibold text-gray-900">Traffic Overview</h3>
                    <p className="text-sm text-gray-500">
                        Total Visitors: {data.totalVisitors.toLocaleString()}
                    </p>
                </div>
                <div className="flex space-x-4">
                    <select
                        value={chartType}
                        onChange={(e) => setChartType(e.target.value)}
                        className="text-sm border border-gray-200 rounded-lg px-3 py-2"
                    >
                        <option value="area">Area Chart</option>
                        <option value="line">Line Chart</option>
                        <option value="bar">Bar Chart</option>
                    </select>
                    <select
                        value={timeRange}
                        onChange={(e) => setTimeRange(e.target.value)}
                        className="text-sm border border-gray-200 rounded-lg px-3 py-2"
                    >
                        <option value="7d">Last 7 days</option>
                        <option value="30d">Last 30 days</option>
                        <option value="90d">Last 90 days</option>
                    </select>
                </div>
            </div>

            <div className="h-80 relative">
                <canvas id="trafficChart"></canvas>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                <MetricTile
                    label="Organic Traffic"
                    value={data.currentOrganic}
                    change={data.organicChange}
                    icon="🔍"
                />
                <MetricTile
                    label="Paid Traffic"
                    value={data.currentPaid}
                    change={data.paidChange}
                    icon="💰"
                />
                <MetricTile
                    label="Bounce Rate"
                    value={`${data.bounceRate}%`}
                    change={data.bounceRateChange}
                    icon="↩️"
                    inverseTrend={true}
                />
                <MetricTile
                    label="Avg. Session"
                    value={`${data.avgSession}m`}
                    change={data.sessionChange}
                    icon="⏱️"
                />
            </div>
        </div>
    );
}

function MetricTile({ label, value, change, icon, inverseTrend = false }) {
    const isPositive = inverseTrend ? change < 0 : change > 0;
    const trendColor = isPositive ? 'text-green-600' : 'text-red-600';
    const trendIcon = isPositive ? '↑' : '↓';

    return (
        <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">{label}</span>
                <span className="text-lg">{icon}</span>
            </div>
            <div className="text-2xl font-semibold text-gray-900">{value}</div>
            <div className={`text-sm font-medium ${trendColor} flex items-center mt-1`}>
                {trendIcon} {Math.abs(change)}%
                <span className="text-gray-500 ml-1">vs last period</span>
            </div>
        </div>
    );
}
