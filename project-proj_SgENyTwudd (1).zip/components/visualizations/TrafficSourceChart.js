function TrafficSourceChart({ data }) {
    const [chartData, setChartData] = React.useState(null);

    React.useEffect(() => {
        try {
            const ctx = document.getElementById('trafficSourceChart').getContext('2d');
            if (chartData) chartData.destroy();
            
            const newChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Direct', 'Organic', 'Referral', 'Social'],
                    datasets: [{
                        data: [data.direct, data.organic, data.referral, data.social],
                        backgroundColor: [
                            'rgba(99, 102, 241, 0.8)',  // Primary color
                            'rgba(16, 185, 129, 0.8)',  // Success color
                            'rgba(245, 158, 11, 0.8)',  // Warning color
                            'rgba(236, 72, 153, 0.8)'   // Pink color
                        ],
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '75%',
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                color: '#4B5563',
                                font: {
                                    family: 'Inter',
                                    size: 12
                                },
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(255, 255, 255, 0.9)',
                            titleColor: '#111827',
                            bodyColor: '#4B5563',
                            borderColor: '#E5E7EB',
                            borderWidth: 1,
                            padding: 12,
                            cornerRadius: 8,
                            displayColors: true,
                            boxPadding: 6,
                            usePointStyle: true,
                            callbacks: {
                                label: (context) => {
                                    const value = context.raw;
                                    const percentage = ((value / data.total) * 100).toFixed(1);
                                    return `${context.label}: ${percentage}% (${value.toLocaleString()})`;
                                }
                            }
                        }
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true,
                        duration: 1000,
                        easing: 'easeOutQuart'
                    }
                }
            });
            setChartData(newChart);
        } catch (error) {
            reportError(error);
        }
    }, [data]);

    const totalVisits = Object.values(data).reduce((a, b) => a + b, 0);

    return (
        <div data-name="traffic-source-chart" className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h3 className="text-lg font-semibold text-gray-900">Traffic Sources</h3>
                    <p className="text-sm text-gray-500 mt-1">
                        {totalVisits.toLocaleString()} total visits
                    </p>
                </div>
                <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700">
                    <option>Last 7 days</option>
                    <option>Last 30 days</option>
                    <option>Last 90 days</option>
                </select>
            </div>
            <div className="relative h-64">
                <canvas id="trafficSourceChart"></canvas>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                {Object.entries(data).map(([source, value]) => (
                    <div key={source} className="text-center">
                        <div className="text-2xl font-semibold text-gray-900">
                            {((value / totalVisits) * 100).toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-500 capitalize">
                            {source}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
