function RevenueMetrics({ data }) {
    const [chartInstance, setChartInstance] = React.useState(null);

    React.useEffect(() => {
        try {
            const ctx = document.getElementById('revenueChart').getContext('2d');
            if (chartInstance) {
                chartInstance.destroy();
            }

            const newChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.periods,
                    datasets: [{
                        label: 'Revenue',
                        data: data.values,
                        backgroundColor: '#6366F1',
                        borderRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#E5E7EB'
                            },
                            ticks: {
                                callback: (value) => `$${value.toLocaleString()}`
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });

            setChartInstance(newChart);
        } catch (error) {
            reportError(error);
        }
    }, [data]);

    return (
        <div className="h-64">
            <canvas id="revenueChart"></canvas>
        </div>
    );
}
