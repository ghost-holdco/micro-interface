function Tooltip({ children, content, position = 'top' }) {
    const [isVisible, setIsVisible] = React.useState(false);
    const [tooltipPosition, setTooltipPosition] = React.useState({ top: 0, left: 0 });
    const triggerRef = React.useRef(null);
    const tooltipRef = React.useRef(null);

    const calculatePosition = () => {
        if (!triggerRef.current || !tooltipRef.current) return;

        const triggerRect = triggerRef.current.getBoundingClientRect();
        const tooltipRect = tooltipRef.current.getBoundingClientRect();

        let top, left;

        switch (position) {
            case 'top':
                top = -tooltipRect.height - 8;
                left = (triggerRect.width - tooltipRect.width) / 2;
                break;
            case 'bottom':
                top = triggerRect.height + 8;
                left = (triggerRect.width - tooltipRect.width) / 2;
                break;
            case 'left':
                top = (triggerRect.height - tooltipRect.height) / 2;
                left = -tooltipRect.width - 8;
                break;
            case 'right':
                top = (triggerRect.height - tooltipRect.height) / 2;
                left = triggerRect.width + 8;
                break;
            default:
                top = -tooltipRect.height - 8;
                left = (triggerRect.width - tooltipRect.width) / 2;
        }

        setTooltipPosition({ top, left });
    };

    React.useEffect(() => {
        if (isVisible) {
            calculatePosition();
            window.addEventListener('scroll', calculatePosition);
            window.addEventListener('resize', calculatePosition);
        }

        return () => {
            window.removeEventListener('scroll', calculatePosition);
            window.removeEventListener('resize', calculatePosition);
        };
    }, [isVisible]);

    return (
        <div 
            className="relative inline-block"
            onMouseEnter={() => setIsVisible(true)}
            onMouseLeave={() => setIsVisible(false)}
            ref={triggerRef}
        >
            {children}
            {isVisible && (
                <div
                    ref={tooltipRef}
                    style={{
                        top: tooltipPosition.top,
                        left: tooltipPosition.left
                    }}
                    className="absolute z-50 px-3 py-2 text-sm font-medium text-white bg-gray-900 rounded-lg shadow-sm 
                             min-w-max max-w-xs whitespace-normal break-words"
                >
                    {content}
                    <div 
                        className={`absolute w-2 h-2 bg-gray-900 transform rotate-45 
                            ${position === 'top' ? 'bottom-[-4px] left-1/2 -translate-x-1/2' : 
                              position === 'bottom' ? 'top-[-4px] left-1/2 -translate-x-1/2' :
                              position === 'left' ? 'right-[-4px] top-1/2 -translate-y-1/2' :
                              'left-[-4px] top-1/2 -translate-y-1/2'}`}
                    />
                </div>
            )}
        </div>
    );
}
