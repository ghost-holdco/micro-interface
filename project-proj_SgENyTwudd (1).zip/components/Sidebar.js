function Sidebar({ categories, onCategorySelect, selectedCategory }) {
    return (
        <div data-name="sidebar" className="sidebar bg-gray-100 w-64 p-4">
            <h2 data-name="categories-title" className="text-lg font-semibold mb-4">Categories</h2>
            <ul className="space-y-2">
                {categories.map(category => (
                    <li 
                        data-name={`category-${category}`}
                        key={category}
                        className={`cursor-pointer p-2 rounded ${selectedCategory === category ? 'bg-blue-500 text-white' : 'hover:bg-gray-200'}`}
                        onClick={() => onCategorySelect(category)}
                    >
                        {category}
                    </li>
                ))}
            </ul>
        </div>
    );
}
