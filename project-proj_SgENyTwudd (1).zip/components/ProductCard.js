function ProductCard({ product }) {
    const [activeTab, setActiveTab] = React.useState('overview');

    const tabs = [
        { id: 'overview', label: 'Overview', icon: '📊' },
        { id: 'analytics', label: 'Analytics', icon: '📈' },
        { id: 'monitoring', label: 'Monitoring', icon: '🔍' },
        { id: 'resources', label: 'Resources', icon: '🛠️' }
    ];

    const handleUpdateResource = async (updatedResource) => {
        try {
            // Here you would update the resource in your backend
            console.log('Updating resource:', updatedResource);
        } catch (error) {
            reportError(error);
        }
    };

    console.log('Current tab:', activeTab); // Debug log
    console.log('Product data:', product); // Debug log

    return (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            {/* Header Section */}
            <div className="p-6 border-b border-gray-100">
                <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 rounded-xl bg-primary-600 flex items-center justify-center">
                            <span className="text-xl font-semibold text-white">
                                {product.objectData.name.charAt(0)}
                            </span>
                        </div>
                        <div>
                            <h3 className="text-xl font-semibold text-gray-900 mb-1">
                                {product.objectData.name}
                            </h3>
                            <div className="flex items-center space-x-3">
                                <span className="text-sm text-gray-500">{product.objectData.domain}</span>
                                <StatusBadge status={product.objectData.metrics.status} />
                            </div>
                        </div>
                    </div>
                    <div className="flex items-center space-x-3">
                        <button 
                            onClick={() => window.open(product.objectData.domain, '_blank')}
                            className="px-3 py-1.5 text-sm font-medium text-gray-700 hover:text-gray-900"
                            title="Visit Website"
                        >
                            🌐 Visit Site
                        </button>
                        <button 
                            onClick={() => window.open(product.objectData.githubUrl, '_blank')}
                            className="px-3 py-1.5 text-sm font-medium text-gray-700 hover:text-gray-900"
                            title="View Source Code"
                        >
                            📦 Repository
                        </button>
                    </div>
                </div>

                {/* Tab Navigation */}
                <div className="flex space-x-6 mt-6">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`flex items-center space-x-2 pb-2 text-sm font-medium border-b-2 transition-colors duration-200 ${
                                activeTab === tab.id 
                                    ? 'border-primary-600 text-primary-600' 
                                    : 'border-transparent text-gray-500 hover:text-gray-700'
                            }`}
                        >
                            <span>{tab.icon}</span>
                            <span>{tab.label}</span>
                        </button>
                    ))}
                </div>
            </div>

            {/* Content Section */}
            <div className="p-6">
                {activeTab === 'overview' && (
                    <Overview product={product.objectData} metrics={product.objectData.metrics} />
                )}
                {activeTab === 'analytics' && (
                    <Analytics metrics={product.objectData.metrics} />
                )}
                {activeTab === 'monitoring' && (
                    <Monitoring metrics={product.objectData.metrics} />
                )}
                {activeTab === 'resources' && (
                    <ResourcesSection product={product.objectData} onUpdateResource={handleUpdateResource} />
                )}
            </div>
        </div>
    );
}

function StatusBadge({ status }) {
    const statusConfig = {
        healthy: {
            bg: 'bg-green-100',
            text: 'text-green-800',
            label: 'Healthy'
        },
        warning: {
            bg: 'bg-yellow-100',
            text: 'text-yellow-800',
            label: 'Warning'
        },
        error: {
            bg: 'bg-red-100',
            text: 'text-red-800',
            label: 'Error'
        }
    };

    const config = statusConfig[status] || statusConfig.error;

    return (
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
            {config.label}
        </span>
    );
}
