function TechList({ technologies }) {
    return (
        <div data-name="tech-list" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
            {technologies.map(tech => (
                <TechCard key={tech.id} tech={tech} />
            ))}
        </div>
    );
}
