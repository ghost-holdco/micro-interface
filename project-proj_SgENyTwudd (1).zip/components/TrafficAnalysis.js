function TrafficAnalysis({ domain }) {
    const [data, setData] = React.useState(null);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState(null);

    React.useEffect(() => {
        loadData();
    }, [domain]);

    async function loadData() {
        try {
            setLoading(true);
            setError(null);

            // Use test data instead of real API calls
            const testData = {
                traffic: {
                    organicTraffic: 125000,
                    paidTraffic: 45000,
                    backlinks: 250000,
                    referringDomains: 15000,
                    organicKeywords: 85000,
                    trafficValue: 450000,
                    trafficSources: {
                        organic: 65,
                        paid: 15,
                        direct: 12,
                        social: 8
                    }
                },
                performance: {
                    score: 92,
                    firstContentfulPaint: "1.2s",
                    speedIndex: "2.1s",
                    timeToInteractive: "3.1s"
                },
                ssl: {
                    grade: "A+",
                    validDays: 90,
                    issuer: "Let's Encrypt"
                },
                lastUpdated: new Date().toISOString()
            };

            setData(testData);
        } catch (error) {
            reportError(error);
            setError(error.message);
        } finally {
            setLoading(false);
        }
    }

    if (loading) {
        return <LoadingSpinner />;
    }

    if (error) {
        return (
            <div className="p-4 bg-red-50 text-red-600 rounded-lg">
                <p>Error loading analysis: {error}</p>
                <button 
                    onClick={loadData}
                    className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                    Retry
                </button>
            </div>
        );
    }

    if (!data) return null;

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <MetricCard
                    title="Organic Traffic"
                    value={data.traffic.organicTraffic.toLocaleString()}
                    icon="🔍"
                />
                <MetricCard
                    title="Paid Traffic"
                    value={data.traffic.paidTraffic.toLocaleString()}
                    icon="💰"
                />
                <MetricCard
                    title="Backlinks"
                    value={data.traffic.backlinks.toLocaleString()}
                    icon="🔗"
                />
                <MetricCard
                    title="Domain Rating"
                    value={data.traffic.domainRating || "N/A"}
                    icon="⭐"
                />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl shadow-sm p-6">
                    <h3 className="text-lg font-semibold mb-4">Traffic Sources</h3>
                    <div className="h-64">
                        <TrafficSourcesChart data={data.traffic.trafficSources} />
                    </div>
                </div>
                
                <div className="bg-white rounded-xl shadow-sm p-6">
                    <h3 className="text-lg font-semibold mb-4">Performance Metrics</h3>
                    <div className="space-y-4">
                        <MetricBar
                            label="Performance Score"
                            value={data.performance.score}
                            max={100}
                        />
                        <MetricBar
                            label="First Paint"
                            value={parseFloat(data.performance.firstContentfulPaint)}
                            max={5}
                            unit="s"
                        />
                        <MetricBar
                            label="Speed Index"
                            value={parseFloat(data.performance.speedIndex)}
                            max={5}
                            unit="s"
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}

function MetricCard({ title, value, icon }) {
    return (
        <div className="bg-white rounded-xl shadow-sm p-4">
            <div className="flex items-center justify-between mb-2">
                <span className="text-gray-500 text-sm">{title}</span>
                <span className="text-xl">{icon}</span>
            </div>
            <div className="text-2xl font-semibold">{value}</div>
        </div>
    );
}

function MetricBar({ label, value, max, unit = '' }) {
    const percentage = (value / max) * 100;
    
    return (
        <div className="space-y-2">
            <div className="flex justify-between text-sm">
                <span className="text-gray-600">{label}</span>
                <span className="font-medium">{value}{unit}</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div 
                    className="h-full bg-primary-600 rounded-full"
                    style={{ width: `${percentage}%` }}
                />
            </div>
        </div>
    );
}

function TrafficSourcesChart({ data }) {
    return (
        <div className="relative h-full">
            {/* Replace with actual chart implementation */}
            <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                Chart Placeholder
            </div>
        </div>
    );
}
