function TechCard({ tech }) {
    return (
        <div data-name={`tech-card-${tech.id}`} className="tech-card bg-white p-4 rounded-lg shadow-md">
            <h3 data-name="tech-name" className="text-lg font-semibold">{tech.name}</h3>
            <p data-name="tech-category" className="text-sm text-gray-600">{tech.category}</p>
            <div data-name="tech-details" className="mt-2">
                <p data-name="tech-description" className="text-gray-700">{tech.description}</p>
                <div data-name="tech-meta" className="mt-2 flex justify-between text-sm text-gray-500">
                    <span>Version: {tech.version}</span>
                    <span>Last Updated: {new Date(tech.updatedAt).toLocaleDateString()}</span>
                </div>
            </div>
        </div>
    );
}
