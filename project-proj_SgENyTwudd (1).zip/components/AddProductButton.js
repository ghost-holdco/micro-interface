function AddProductButton({ onClick }) {
    return (
        <button
            data-name="add-product-trigger"
            onClick={onClick}
            className="fixed bottom-8 right-8 flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-primary to-secondary text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 z-50"
        >
            <span className="text-xl">+</span>
            <span className="font-medium">Add Micro-SaaS</span>
        </button>
    );
}
