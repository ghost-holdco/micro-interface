function Header({ selectedProduct, onProductSelect, onBackToGrid, view }) {
    const [isProductsOpen, setIsProductsOpen] = React.useState(false);
    const productAPI = ProductAPI();
    const [products, setProducts] = React.useState([]);

    React.useEffect(() => {
        loadProducts();
    }, []);

    async function loadProducts() {
        try {
            const prods = await productAPI.getProducts();
            setProducts(prods);
        } catch (error) {
            reportError(error);
        }
    }

    return (
        <header data-name="header" className="bg-gray-800 border-b border-gray-700">
            <div className="container mx-auto px-4 py-4">
                <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-8">
                        <h1 className="text-xl font-semibold text-white">
                            {view === 'detail' ? (
                                <button 
                                    onClick={onBackToGrid}
                                    className="flex items-center hover:text-gray-300 transition-colors"
                                >
                                    <span className="text-primary-400">Micro-SaaS</span> Portfolio
                                </button>
                            ) : (
                                <span>
                                    <span className="text-primary-400">Micro-SaaS</span> Portfolio
                                </span>
                            )}
                        </h1>
                        {view === 'detail' && selectedProduct && (
                            <div className="flex items-center space-x-4">
                                <div className="h-6 w-px bg-gray-700"></div>
                                <span className="text-gray-300">{selectedProduct.objectData.name}</span>
                            </div>
                        )}
                    </div>
                    <nav className="flex items-center space-x-4">
                        <button 
                            className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
                        >
                            Documentation
                        </button>
                        <button 
                            className="bg-gray-700 text-white px-3 py-2 rounded-md text-sm font-medium hover:bg-gray-600 transition-colors"
                        >
                            Settings
                        </button>
                    </nav>
                </div>
            </div>
        </header>
    );
}
