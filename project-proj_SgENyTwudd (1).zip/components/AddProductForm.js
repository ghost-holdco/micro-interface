function AddProductForm({ onSubmit }) {
    const [formData, setFormData] = React.useState({
        name: '',
        type: 'Micro-SaaS',
        githubUrl: '',
        domain: '',
        hosting: '',
        database: '',
        imageStorage: '',
        auth: '',
        analytics: '',
        errorTracking: '',
        seoTool: '',
        emailMarketing: '',
        notifications: '',
        customerSupport: ''
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        try {
            onSubmit(formData);
            setFormData({
                name: '',
                type: 'Micro-SaaS',
                githubUrl: '',
                domain: '',
                hosting: '',
                database: '',
                imageStorage: '',
                auth: '',
                analytics: '',
                errorTracking: '',
                seoTool: '',
                emailMarketing: '',
                notifications: '',
                customerSupport: ''
            });
        } catch (error) {
            reportError(error);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    return (
        <form data-name="add-product-form" onSubmit={handleSubmit} className="glass-card p-6 rounded-xl">
            <h2 data-name="form-title" className="text-xl font-bold mb-6 text-white">
                Add New Micro-SaaS
            </h2>

            {/* Basic Information Section */}
            <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-200 mb-4 uppercase tracking-wider">Basic Information</h3>
                <div className="grid gap-4">
                    <FormField
                        name="name"
                        label="Product Name"
                        value={formData.name}
                        onChange={handleChange}
                        required={true}
                    />
                    <FormField
                        name="domain"
                        label="Domain"
                        value={formData.domain}
                        onChange={handleChange}
                        placeholder="example.com"
                        required={true}
                    />
                    <FormField
                        name="githubUrl"
                        label="GitHub Repository"
                        value={formData.githubUrl}
                        onChange={handleChange}
                        required={true}
                    />
                </div>
            </div>

            {/* Infrastructure Section */}
            <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-200 mb-4 uppercase tracking-wider">Infrastructure</h3>
                <div className="grid grid-cols-2 gap-4">
                    <FormField
                        name="hosting"
                        label="Hosting"
                        value={formData.hosting}
                        onChange={handleChange}
                        type="select"
                        options={['Vercel', 'Netlify', 'AWS', 'DigitalOcean', 'Other']}
                    />
                    <FormField
                        name="database"
                        label="Database"
                        value={formData.database}
                        onChange={handleChange}
                        type="select"
                        options={['Supabase', 'Firebase', 'MongoDB', 'PostgreSQL', 'Other']}
                    />
                    <FormField
                        name="imageStorage"
                        label="Storage"
                        value={formData.imageStorage}
                        onChange={handleChange}
                        type="select"
                        options={['AWS S3', 'Cloudinary', 'Firebase Storage', 'Other']}
                    />
                    <FormField
                        name="auth"
                        label="Authentication"
                        value={formData.auth}
                        onChange={handleChange}
                        type="select"
                        options={['Google OAuth', 'Auth0', 'Firebase Auth', 'Custom', 'Other']}
                    />
                </div>
            </div>

            {/* Monitoring & Analytics */}
            <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-200 mb-4 uppercase tracking-wider">Monitoring & Analytics</h3>
                <div className="grid grid-cols-2 gap-4">
                    <FormField
                        name="analytics"
                        label="Analytics"
                        value={formData.analytics}
                        onChange={handleChange}
                        type="select"
                        options={['Plausible', 'Google Analytics', 'Mixpanel', 'Other']}
                    />
                    <FormField
                        name="errorTracking"
                        label="Error Tracking"
                        value={formData.errorTracking}
                        onChange={handleChange}
                        type="select"
                        options={['Sentry', 'Rollbar', 'LogRocket', 'Other']}
                    />
                </div>
            </div>

            {/* Marketing & Support */}
            <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-200 mb-4 uppercase tracking-wider">Marketing & Support</h3>
                <div className="grid grid-cols-2 gap-4">
                    <FormField
                        name="seoTool"
                        label="SEO"
                        value={formData.seoTool}
                        onChange={handleChange}
                        type="select"
                        options={['Ahrefs', 'SEMrush', 'Moz', 'Other']}
                    />
                    <FormField
                        name="emailMarketing"
                        label="Email"
                        value={formData.emailMarketing}
                        onChange={handleChange}
                        type="select"
                        options={['Mailchimp', 'ConvertKit', 'SendGrid', 'Other']}
                    />
                    <FormField
                        name="notifications"
                        label="Notifications"
                        value={formData.notifications}
                        onChange={handleChange}
                        type="select"
                        options={['OneSignal', 'Firebase Cloud Messaging', 'Pushover', 'Other']}
                    />
                    <FormField
                        name="customerSupport"
                        label="Support"
                        value={formData.customerSupport}
                        onChange={handleChange}
                        type="select"
                        options={['Intercom', 'Crisp', 'Zendesk', 'Other']}
                    />
                </div>
            </div>

            <button
                data-name="submit-button"
                type="submit"
                className="w-full button-primary py-3 px-4 rounded-lg font-medium text-white hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
                Add Micro-SaaS
            </button>
        </form>
    );
}

function FormField({ name, label, value, onChange, type = "text", options = [], required = false, placeholder = "" }) {
    return (
        <div data-name={`form-field-${name}`} className="w-full">
            <label className="block text-sm font-medium text-gray-200 mb-1">
                {label}
            </label>
            {type === "select" ? (
                <select
                    name={name}
                    value={value}
                    onChange={onChange}
                    className="glass-input w-full rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:ring-offset-2"
                    required={required}
                >
                    <option value="">Select {label}</option>
                    {options.map(option => (
                        <option key={option} value={option}>{option}</option>
                    ))}
                </select>
            ) : (
                <input
                    type={type}
                    name={name}
                    value={value}
                    onChange={onChange}
                    placeholder={placeholder}
                    className="glass-input w-full rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary focus:ring-offset-2"
                    required={required}
                />
            )}
        </div>
    );
}
