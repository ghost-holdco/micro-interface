function TestTrafficAnalysis() {
    const testDomains = [
        'ahrefs.com',
        'moz.com',
        'semrush.com'
    ];
    const [selectedDomain, setSelectedDomain] = React.useState(testDomains[0]);
    const [testResults, setTestResults] = React.useState(null);
    const [running, setRunning] = React.useState(false);

    async function runTest() {
        try {
            setRunning(true);
            setTestResults(null);

            // Test cache operations
            const cache = await TrafficAnalysisCache();
            await cache.clearCache(selectedDomain);
            
            // First run - should fetch fresh data
            console.log('Running first analysis (fresh data)...');
            const startTime1 = performance.now();
            const analyzer = SimpleTrafficAnalyzer(selectedDomain, config.ahrefsApiKey);
            const freshData = await analyzer.analyzeTraffic();
            const endTime1 = performance.now();

            // Second run - should use cache
            console.log('Running second analysis (cached data)...');
            const startTime2 = performance.now();
            const cachedData = await analyzer.analyzeTraffic();
            const endTime2 = performance.now();

            const cacheStats = await cache.getCacheStats();

            setTestResults({
                domain: selectedDomain,
                freshDataTime: endTime1 - startTime1,
                cachedDataTime: endTime2 - startTime2,
                cacheStats,
                trafficData: freshData
            });
        } catch (error) {
            reportError(error);
            setTestResults({
                error: error.message
            });
        } finally {
            setRunning(false);
        }
    }

    return (
        <div className="max-w-4xl mx-auto p-6">
            <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold text-gray-900">Traffic Analysis Test</h2>
                    <div className="flex items-center space-x-4">
                        <select
                            value={selectedDomain}
                            onChange={(e) => setSelectedDomain(e.target.value)}
                            className="text-sm border border-gray-200 rounded-lg px-3 py-2"
                            disabled={running}
                        >
                            {testDomains.map(domain => (
                                <option key={domain} value={domain}>{domain}</option>
                            ))}
                        </select>
                        <button
                            onClick={runTest}
                            disabled={running}
                            className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
                        >
                            {running ? 'Running Test...' : 'Run Test'}
                        </button>
                    </div>
                </div>

                {running && (
                    <div className="flex items-center justify-center p-12">
                        <LoadingSpinner />
                        <span className="ml-3">Running traffic analysis test...</span>
                    </div>
                )}

                {testResults && !testResults.error && (
                    <div className="space-y-6">
                        <div className="grid grid-cols-2 gap-6">
                            <div className="bg-gray-50 rounded-lg p-4">
                                <h3 className="text-sm font-medium text-gray-700 mb-2">Performance</h3>
                                <div className="space-y-2">
                                    <div className="flex justify-between">
                                        <span className="text-sm text-gray-600">Fresh Data Time:</span>
                                        <span className="text-sm font-medium text-gray-900">
                                            {testResults.freshDataTime.toFixed(2)}ms
                                        </span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-sm text-gray-600">Cached Data Time:</span>
                                        <span className="text-sm font-medium text-gray-900">
                                            {testResults.cachedDataTime.toFixed(2)}ms
                                        </span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-sm text-gray-600">Speed Improvement:</span>
                                        <span className="text-sm font-medium text-green-600">
                                            {((testResults.freshDataTime - testResults.cachedDataTime) / testResults.freshDataTime * 100).toFixed(1)}%
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-gray-50 rounded-lg p-4">
                                <h3 className="text-sm font-medium text-gray-700 mb-2">Cache Stats</h3>
                                <div className="space-y-2">
                                    <div className="flex justify-between">
                                        <span className="text-sm text-gray-600">Total Entries:</span>
                                        <span className="text-sm font-medium text-gray-900">
                                            {testResults.cacheStats.totalEntries}
                                        </span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-sm text-gray-600">Newest Entry:</span>
                                        <span className="text-sm font-medium text-gray-900">
                                            {new Date(testResults.cacheStats.newestEntry).toLocaleString()}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="border-t border-gray-200 pt-6">
                            <h3 className="text-sm font-medium text-gray-700 mb-4">Traffic Analysis Results</h3>
                            <TrafficAnalysis 
                                domain={selectedDomain}
                                ahrefsApiKey={config.ahrefsApiKey}
                            />
                        </div>
                    </div>
                )}

                {testResults && testResults.error && (
                    <div className="p-4 bg-red-50 text-red-600 rounded-lg">
                        <p>Error running test: {testResults.error}</p>
                        <button 
                            onClick={runTest}
                            className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                        >
                            Retry Test
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}
