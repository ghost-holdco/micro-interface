const mockAnalysisData = {
    traffic: {
        organicTraffic: 125000,
        paidTraffic: 45000,
        backlinks: 250000,
        referringDomains: 15000,
        organicKeywords: 85000,
        trafficValue: 450000,
        trafficTrend: {
            organic: [95000, 105000, 115000, 125000],
            paid: [35000, 38000, 42000, 45000],
            periods: ['Jan', 'Feb', 'Mar', 'Apr']
        },
        trafficSources: {
            organic: 65,
            paid: 15,
            direct: 12,
            social: 8
        },
        geographicData: {
            US: 45,
            UK: 15,
            DE: 10,
            FR: 8,
            Others: 22
        },
        deviceData: {
            desktop: 65,
            mobile: 30,
            tablet: 5
        }
    },
    performance: {
        score: 92,
        firstContentfulPaint: "1.2s",
        speedIndex: "2.1s",
        largestContentfulPaint: "2.4s",
        timeToInteractive: "3.1s",
        totalBlockingTime: "150ms",
        cumulativeLayoutShift: "0.1",
        performanceTrend: {
            scores: [88, 90, 91, 92],
            periods: ['Jan', 'Feb', 'Mar', 'Apr']
        },
        resourceStats: {
            totalResources: 45,
            imageSize: "850KB",
            cssSize: "120KB",
            jsSize: "450KB",
            otherSize: "80KB"
        }
    },
    accessibility: {
        score: 98,
        issues: {
            critical: 0,
            serious: 1,
            moderate: 2,
            minor: 3
        },
        elements: {
            total: 500,
            withIssues: 6
        },
        trend: [96, 96, 97, 98]
    },
    bestPractices: {
        score: 95,
        checks: {
            passed: 28,
            failed: 2,
            notApplicable: 3
        },
        trend: [93, 94, 94, 95]
    },
    seo: {
        score: 97,
        factors: {
            mobileOptimization: 100,
            contentQuality: 95,
            technicalSEO: 96,
            userExperience: 97
        },
        trend: [95, 96, 96, 97],
        keywords: {
            ranking: 450,
            improving: 85,
            declining: 23
        }
    },
    ssl: {
        grade: "A+",
        hasWarnings: false,
        isExceptional: true,
        details: {
            cert: {
                subject: "*.example.com",
                issuer: "Let's Encrypt Authority X3",
                validFrom: "2024-01-01",
                validTo: "2024-03-31",
                validDays: 90
            },
            protocols: ["TLS 1.2", "TLS 1.3"],
            cipherSuites: ["ECDHE-ECDSA-AES128-GCM-SHA256", "ECDHE-RSA-AES128-GCM-SHA256"],
            vulnBeast: false,
            heartbleed: false,
            poodle: false,
            freak: false,
            logjam: false,
            drownVulnerable: false
        },
        history: [
            { date: '2024-01-01', grade: 'A+' },
            { date: '2023-10-01', grade: 'A' },
            { date: '2023-07-01', grade: 'A' },
            { date: '2023-04-01', grade: 'A+' }
        ]
    },
    dns: {
        records: {
            status: "healthy",
            records: [
                { type: 'A', data: "192.0.2.1", ttl: 300 },
                { type: 'A', data: "192.0.2.2", ttl: 300 }
            ],
            responseTime: "45ms",
            lastUpdated: "2024-01-20T15:30:00Z"
        },
        nameservers: {
            status: "healthy",
            nameservers: [
                { data: "ns1.example.com", responseTime: "38ms" },
                { data: "ns2.example.com", responseTime: "42ms" }
            ],
            responseTime: "38ms",
            lastChecked: "2024-01-20T15:30:00Z"
        },
        mailservers: {
            status: "healthy",
            mailservers: [
                { priority: 10, data: "mail1.example.com" },
                { priority: 20, data: "mail2.example.com" }
            ],
            responseTime: "42ms",
            spfRecord: "v=spf1 include:_spf.example.com ~all",
            dmarcRecord: "v=DMARC1; p=reject; rua=mailto:dmarc@example.com"
        },
        propagation: {
            complete: true,
            percentage: 100,
            checkedServers: 24
        }
    },
    security: {
        score: 95,
        grade: "A+",
        headers: {
            'Strict-Transport-Security': "max-age=31536000; includeSubDomains",
            'Content-Security-Policy': "default-src 'self'",
            'X-Frame-Options': "DENY",
            'X-Content-Type-Options': "nosniff",
            'Referrer-Policy': "strict-origin-when-cross-origin",
            'Permissions-Policy': "geolocation=(), microphone=()"
        },
        missing: [],
        recommendations: [],
        vulnerabilities: {
            critical: 0,
            high: 0,
            medium: 1,
            low: 2
        },
        scanHistory: [
            { date: '2024-01-20', score: 95, findings: 3 },
            { date: '2024-01-13', score: 94, findings: 4 },
            { date: '2024-01-06', score: 93, findings: 5 },
            { date: '2023-12-30', score: 92, findings: 6 }
        ]
    },
    social: {
        facebook: {
            shares: 25000,
            reactions: 75000,
            comments: 12000,
            trend: {
                shares: [22000, 23000, 24000, 25000],
                reactions: [65000, 68000, 72000, 75000],
                periods: ['Jan', 'Feb', 'Mar', 'Apr']
            }
        },
        twitter: {
            followers: 45000,
            engagement: 2.8,
            tweets: 850,
            trend: {
                followers: [41000, 42500, 44000, 45000],
                engagement: [2.5, 2.6, 2.7, 2.8],
                periods: ['Jan', 'Feb', 'Mar', 'Apr']
            }
        },
        linkedin: {
            followers: 28000,
            engagementRate: 3.2,
            posts: 420,
            trend: {
                followers: [25000, 26000, 27000, 28000],
                engagement: [3.0, 3.1, 3.1, 3.2],
                periods: ['Jan', 'Feb', 'Mar', 'Apr']
            }
        }
    },
    uptime: {
        last24Hours: 100,
        last7Days: 99.98,
        last30Days: 99.95,
        incidents: [
            {
                date: '2024-01-15',
                duration: '5m',
                type: 'Performance Degradation',
                affected: 'API Endpoints'
            },
            {
                date: '2024-01-08',
                duration: '12m',
                type: 'Partial Outage',
                affected: 'Database'
            }
        ],
        responseTime: {
            p50: 180,
            p95: 250,
            p99: 450
        }
    },
    lastUpdated: new Date().toISOString()
};

const mockDomainData = {
    "ahrefs.com": {
        ...mockAnalysisData,
        traffic: {
            ...mockAnalysisData.traffic,
            organicTraffic: 2500000,
            paidTraffic: 150000,
            trafficValue: 8500000,
            trafficTrend: {
                organic: [2200000, 2300000, 2400000, 2500000],
                paid: [130000, 135000, 142000, 150000],
                periods: ['Jan', 'Feb', 'Mar', 'Apr']
            }
        }
    },
    "moz.com": {
        ...mockAnalysisData,
        traffic: {
            ...mockAnalysisData.traffic,
            organicTraffic: 1800000,
            paidTraffic: 120000,
            trafficValue: 6200000,
            trafficTrend: {
                organic: [1650000, 1700000, 1750000, 1800000],
                paid: [100000, 108000, 115000, 120000],
                periods: ['Jan', 'Feb', 'Mar', 'Apr']
            }
        }
    },
    "semrush.com": {
        ...mockAnalysisData,
        traffic: {
            ...mockAnalysisData.traffic,
            organicTraffic: 3200000,
            paidTraffic: 180000,
            trafficValue: 9800000,
            trafficTrend: {
                organic: [2900000, 3000000, 3100000, 3200000],
                paid: [160000, 165000, 172000, 180000],
                periods: ['Jan', 'Feb', 'Mar', 'Apr']
            }
        }
    }
};
