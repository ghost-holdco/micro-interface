const config = {
    ahrefsApiKey: '0teeYECpAuJsSt3wsCJF0rcto87oFbQB3B-XWkR_',
    refreshInterval: 3600000, // 1 hour in milliseconds
    maxRequestsPerHour: 100, // Ahrefs rate limit
    retryAttempts: 3,
    retryDelay: 1000, // 1 second
    apis: {
        ahrefs: {
            baseUrl: 'https://api.ahrefs.com/v1',
            endpoints: {
                siteExplorer: '/site-explorer',
                metrics: '/metrics',
                backlinks: '/backlinks',
                keywords: '/keywords'
            }
        },
        pageSpeed: {
            baseUrl: 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed'
        },
        ssl: {
            baseUrl: 'https://api.ssllabs.com/api/v3'
        },
        dns: {
            baseUrl: 'https://dns.google/resolve'
        }
    }
};

const rateLimiter = {
    requests: 0,
    lastReset: Date.now(),
    
    async checkLimit() {
        try {
            const now = Date.now();
            if (now - this.lastReset > 3600000) {
                this.requests = 0;
                this.lastReset = now;
            }
            
            if (this.requests >= config.maxRequestsPerHour) {
                throw new Error('Rate limit exceeded. Please try again later.');
            }
            
            this.requests++;
            return true;
        } catch (error) {
            reportError(error);
            throw error;
        }
    },

    async waitForReset() {
        const now = Date.now();
        const timeUntilReset = 3600000 - (now - this.lastReset);
        if (timeUntilReset > 0) {
            await new Promise(resolve => setTimeout(resolve, timeUntilReset));
        }
        this.requests = 0;
        this.lastReset = Date.now();
    }
};

const errorHandler = {
    handleApiError(error, service) {
        reportError({
            service,
            message: error.message,
            timestamp: new Date().toISOString(),
            details: error.stack
        });

        // Determine if we should retry based on error type
        const shouldRetry = error.message.includes('429') || // Rate limit
                          error.message.includes('500') || // Server error
                          error.message.includes('503'); // Service unavailable

        return {
            shouldRetry,
            waitTime: error.message.includes('429') ? 60000 : config.retryDelay
        };
    }
};
