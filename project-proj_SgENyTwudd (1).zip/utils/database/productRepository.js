// Remove export and make it globally available
function ProductRepository() {
    const trickleObjAPI = new TrickleObjectAPI();
    const PRODUCT_OBJECT_TYPE = 'saas-product';

    async function createProduct(productData) {
        try {
            // Add default metrics if not provided
            const defaultMetrics = {
                status: 'healthy',
                performance: 95,
                users: 0,
                revenue: 0,
                revenueTrend: 0,
                usersTrend: 0,
                uptime: 100,
                responseTime: 200,
                sslStatus: 'Valid',
                sslHealth: 'healthy',
                uptimeStatus: 'healthy',
                responseStatus: 'healthy',
                databaseStatus: 'Operational',
                databaseHealth: 'healthy',
                cacheStatus: 'Operational',
                cacheHealth: 'healthy',
                cdnStatus: 'Operational',
                cdnHealth: 'healthy',
                incidents: [],
                traffic: {
                    direct: 0,
                    organic: 0,
                    referral: 0,
                    social: 0,
                    total: 0
                },
                userGrowth: {
                    data: [0, 0, 0, 0, 0, 0],
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
                },
                engagement: {
                    dates: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    activeUsers: [0, 0, 0, 0, 0, 0],
                    sessionDuration: [0, 0, 0, 0, 0, 0],
                    averageSession: 0,
                    sessionTrend: 0,
                    bounceRate: 0,
                    bounceTrend: 0,
                    retention: 0,
                    retentionTrend: 0
                }
            };

            const product = await trickleObjAPI.createObject(PRODUCT_OBJECT_TYPE, {
                ...productData,
                metrics: defaultMetrics,
                createdAt: new Date().toISOString()
            });

            return product;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function updateProduct(productId, productData) {
        try {
            const product = await trickleObjAPI.updateObject(PRODUCT_OBJECT_TYPE, productId, productData);
            return product;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getProduct(productId) {
        try {
            const product = await trickleObjAPI.getObject(PRODUCT_OBJECT_TYPE, productId);
            return product;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function listProducts(limit = 100, descent = true) {
        try {
            const response = await trickleObjAPI.listObjects(PRODUCT_OBJECT_TYPE, limit, descent);
            return response.items;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function deleteProduct(productId) {
        try {
            await trickleObjAPI.deleteObject(PRODUCT_OBJECT_TYPE, productId);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        createProduct,
        updateProduct,
        getProduct,
        listProducts,
        deleteProduct
    };
}
