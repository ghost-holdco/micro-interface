function DatabaseService() {
    const productRepo = ProductRepository();
    const resourceRepo = ResourceRepository();
    const metricsRepo = MetricsRepository();
    const integrationRepo = IntegrationRepository();

    async function initializeProduct(productData) {
        try {
            // Create the main product
            const product = await productRepo.createProduct(productData);

            // Initialize default resources
            const defaultResources = [
                {
                    type: 'hosting',
                    provider: productData.hosting || 'Not configured',
                    status: 'active'
                },
                {
                    type: 'database',
                    provider: productData.database || 'Not configured',
                    status: 'active'
                },
                {
                    type: 'auth',
                    provider: productData.auth || 'Not configured',
                    status: 'active'
                }
            ];

            for (const resource of defaultResources) {
                await resourceRepo.createResource(product.objectId, resource);
            }

            // Initialize metrics
            await metricsRepo.createMetricsSnapshot(product.objectId, {
                users: 0,
                revenue: 0,
                uptime: 100,
                responseTime: 200,
                errorRate: 0
            });

            return product;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getProductDetails(productId) {
        try {
            const [
                product,
                resources,
                metrics,
                integrations
            ] = await Promise.all([
                productRepo.getProduct(productId),
                resourceRepo.listResources(productId),
                metricsRepo.getLatestMetrics(productId),
                integrationRepo.listIntegrations(productId, 'all')
            ]);

            return {
                ...product,
                resources,
                metrics: metrics?.objectData,
                integrations
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function updateProductDetails(productId, updateData) {
        try {
            const updates = [];

            if (updateData.product) {
                updates.push(productRepo.updateProduct(productId, updateData.product));
            }

            if (updateData.resources) {
                for (const resource of updateData.resources) {
                    if (resource.id) {
                        updates.push(resourceRepo.updateResource(productId, resource.id, resource));
                    } else {
                        updates.push(resourceRepo.createResource(productId, resource));
                    }
                }
            }

            if (updateData.metrics) {
                updates.push(metricsRepo.createMetricsSnapshot(productId, updateData.metrics));
            }

            if (updateData.integrations) {
                for (const integration of updateData.integrations) {
                    if (integration.id) {
                        updates.push(
                            integrationRepo.updateIntegration(
                                productId,
                                integration.type,
                                integration.id,
                                integration
                            )
                        );
                    } else {
                        updates.push(
                            integrationRepo.createIntegration(
                                productId,
                                integration.type,
                                integration
                            )
                        );
                    }
                }
            }

            await Promise.all(updates);
            return await getProductDetails(productId);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function deleteProduct(productId) {
        try {
            // Delete all related data first
            const [resources, integrations] = await Promise.all([
                resourceRepo.listResources(productId),
                integrationRepo.listIntegrations(productId, 'all')
            ]);

            const deletions = [
                ...resources.map(resource => 
                    resourceRepo.deleteResource(productId, resource.objectId)
                ),
                ...integrations.map(integration =>
                    integrationRepo.deleteIntegration(productId, integration.objectData.type, integration.objectId)
                )
            ];

            await Promise.all(deletions);

            // Finally delete the product itself
            await productRepo.deleteProduct(productId);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        products: productRepo,
        resources: resourceRepo,
        metrics: metricsRepo,
        integrations: integrationRepo,
        initializeProduct,
        getProductDetails,
        updateProductDetails,
        deleteProduct
    };
}
