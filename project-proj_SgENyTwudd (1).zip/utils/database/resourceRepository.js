function ResourceRepository() {
    const trickleObjAPI = new TrickleObjectAPI();
    const RESOURCE_OBJECT_TYPE = 'product-resource';

    async function createResource(productId, resourceData) {
        try {
            const resource = await trickleObjAPI.createObject(
                `${RESOURCE_OBJECT_TYPE}:${productId}`,
                {
                    ...resourceData,
                    productId,
                    createdAt: new Date().toISOString(),
                    status: 'active'
                }
            );
            return resource;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function updateResource(productId, resourceId, resourceData) {
        try {
            const resource = await trickleObjAPI.updateObject(
                `${RESOURCE_OBJECT_TYPE}:${productId}`,
                resourceId,
                resourceData
            );
            return resource;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getResource(productId, resourceId) {
        try {
            const resource = await trickleObjAPI.getObject(
                `${RESOURCE_OBJECT_TYPE}:${productId}`,
                resourceId
            );
            return resource;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function listResources(productId, limit = 100) {
        try {
            const response = await trickleObjAPI.listObjects(
                `${RESOURCE_OBJECT_TYPE}:${productId}`,
                limit,
                true
            );
            return response.items;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function deleteResource(productId, resourceId) {
        try {
            await trickleObjAPI.deleteObject(
                `${RESOURCE_OBJECT_TYPE}:${productId}`,
                resourceId
            );
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        createResource,
        updateResource,
        getResource,
        listResources,
        deleteResource
    };
}
