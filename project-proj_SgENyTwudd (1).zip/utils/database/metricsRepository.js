function MetricsRepository() {
    const trickleObjAPI = new TrickleObjectAPI();
    const METRICS_OBJECT_TYPE = 'product-metrics';

    async function createMetricsSnapshot(productId, metricsData) {
        try {
            const metrics = await trickleObjAPI.createObject(
                `${METRICS_OBJECT_TYPE}:${productId}`,
                {
                    ...metricsData,
                    productId,
                    timestamp: new Date().toISOString()
                }
            );
            return metrics;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getLatestMetrics(productId) {
        try {
            const response = await trickleObjAPI.listObjects(
                `${METRICS_OBJECT_TYPE}:${productId}`,
                1,
                true
            );
            return response.items[0];
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getMetricsHistory(productId, limit = 30) {
        try {
            const response = await trickleObjAPI.listObjects(
                `${METRICS_OBJECT_TYPE}:${productId}`,
                limit,
                true
            );
            return response.items;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function aggregateMetrics(productId, timeRange) {
        try {
            const metrics = await getMetricsHistory(productId);
            const now = new Date();
            const rangeStart = new Date(now.getTime() - timeRange);

            const filteredMetrics = metrics.filter(metric => 
                new Date(metric.objectData.timestamp) >= rangeStart
            );

            return {
                averages: calculateAverages(filteredMetrics),
                trends: calculateTrends(filteredMetrics),
                summary: generateSummary(filteredMetrics)
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    function calculateAverages(metrics) {
        if (!metrics.length) return null;

        const sums = metrics.reduce((acc, metric) => {
            Object.entries(metric.objectData).forEach(([key, value]) => {
                if (typeof value === 'number') {
                    acc[key] = (acc[key] || 0) + value;
                }
            });
            return acc;
        }, {});

        const averages = {};
        Object.entries(sums).forEach(([key, sum]) => {
            averages[key] = sum / metrics.length;
        });

        return averages;
    }

    function calculateTrends(metrics) {
        if (metrics.length < 2) return null;

        const sortedMetrics = [...metrics].sort((a, b) => 
            new Date(a.objectData.timestamp) - new Date(b.objectData.timestamp)
        );

        const first = sortedMetrics[0].objectData;
        const last = sortedMetrics[sortedMetrics.length - 1].objectData;
        const trends = {};

        Object.entries(last).forEach(([key, value]) => {
            if (typeof value === 'number' && typeof first[key] === 'number') {
                const change = value - first[key];
                const percentChange = (change / first[key]) * 100;
                trends[key] = Math.round(percentChange * 100) / 100;
            }
        });

        return trends;
    }

    function generateSummary(metrics) {
        if (!metrics.length) return null;

        const latest = metrics[0].objectData;
        return {
            status: determineOverallStatus(latest),
            lastUpdated: latest.timestamp,
            totalMetrics: metrics.length,
            timeSpan: getTimeSpan(metrics)
        };
    }

    function determineOverallStatus(metrics) {
        const statusChecks = [
            metrics.uptime >= 99.9,
            metrics.responseTime < 300,
            metrics.errorRate < 1,
            !metrics.incidents?.length
        ];

        const healthyChecks = statusChecks.filter(Boolean).length;
        const healthPercentage = (healthyChecks / statusChecks.length) * 100;

        if (healthPercentage >= 90) return 'healthy';
        if (healthPercentage >= 70) return 'warning';
        return 'error';
    }

    function getTimeSpan(metrics) {
        if (metrics.length < 2) return '0 days';
        
        const oldest = new Date(metrics[metrics.length - 1].objectData.timestamp);
        const newest = new Date(metrics[0].objectData.timestamp);
        const diffDays = Math.round((newest - oldest) / (1000 * 60 * 60 * 24));
        
        return `${diffDays} days`;
    }

    return {
        createMetricsSnapshot,
        getLatestMetrics,
        getMetricsHistory,
        aggregateMetrics
    };
}
