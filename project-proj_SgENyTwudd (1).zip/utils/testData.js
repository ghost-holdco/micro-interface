function TestProductAPI() {
    const testProducts = [
        {
            objectId: 'test-product-1',
            objectType: 'saas-product',
            objectData: {
                name: 'InvoiceNinja',
                domain: 'invoiceninja.app',
                githubUrl: 'https://github.com/invoiceninja/app',
                hosting: 'Vercel',
                database: 'PostgreSQL',
                imageStorage: 'AWS S3',
                auth: 'Auth0',
                analytics: 'Plausible',
                errorTracking: 'Sentry',
                seoTool: 'Ahrefs',
                emailMarketing: 'SendGrid',
                notifications: 'OneSignal',
                customerSupport: 'Intercom',
                metrics: {
                    status: 'healthy',
                    performance: 95,
                    users: 2500,
                    revenue: 12000,
                    revenueTrend: 25,
                    usersTrend: 18,
                    uptime: 99.95,
                    responseTime: 180,
                    sslStatus: 'Valid',
                    sslHealth: 'healthy',
                    uptimeStatus: 'healthy',
                    responseStatus: 'healthy',
                    databaseStatus: 'Operational',
                    databaseHealth: 'healthy',
                    cacheStatus: 'Operational',
                    cacheHealth: 'healthy',
                    cdnStatus: 'Operational',
                    cdnHealth: 'healthy',
                    incidents: [
                        {
                            date: '2024-01-15',
                            duration: '3m',
                            type: 'API Latency',
                            affected: 'Payment Processing'
                        },
                        {
                            date: '2024-01-10',
                            duration: '15m',
                            type: 'Database Slowdown',
                            affected: 'User Authentication'
                        }
                    ],
                    traffic: {
                        direct: 35,
                        organic: 45,
                        referral: 15,
                        social: 5,
                        total: 100
                    },
                    userGrowth: {
                        data: [1800, 2000, 2200, 2300, 2400, 2500],
                        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
                    },
                    engagement: {
                        dates: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                        activeUsers: [1800, 2000, 2200, 2300, 2400, 2500],
                        sessionDuration: [6.2, 6.5, 6.8, 6.7, 7.0, 7.2],
                        averageSession: 7.2,
                        sessionTrend: 15,
                        bounceRate: 28,
                        bounceTrend: -8,
                        retention: 75,
                        retentionTrend: 12
                    }
                }
            },
            createdAt: '2024-01-01T10:00:00Z',
            updatedAt: '2024-01-20T15:30:00Z'
        }
    ];

    let products = [...testProducts];

    const simulateNetworkDelay = () => new Promise(resolve => setTimeout(resolve, Math.random() * 1000));

    return {
        getProducts: async () => {
            try {
                await simulateNetworkDelay();
                return products;
            } catch (error) {
                reportError(error);
                throw error;
            }
        },

        addProduct: async (productData) => {
            try {
                await simulateNetworkDelay();
                
                const newProduct = {
                    objectId: `test-product-${Date.now()}`,
                    objectType: 'saas-product',
                    objectData: {
                        ...productData,
                        metrics: {
                            status: 'healthy',
                            performance: 95,
                            users: 0,
                            revenue: 0,
                            revenueTrend: 0,
                            usersTrend: 0,
                            uptime: 100,
                            responseTime: 200,
                            sslStatus: 'Valid',
                            sslHealth: 'healthy',
                            uptimeStatus: 'healthy',
                            responseStatus: 'healthy',
                            databaseStatus: 'Operational',
                            databaseHealth: 'healthy',
                            cacheStatus: 'Operational',
                            cacheHealth: 'healthy',
                            cdnStatus: 'Operational',
                            cdnHealth: 'healthy',
                            incidents: [],
                            traffic: {
                                direct: 0,
                                organic: 0,
                                referral: 0,
                                social: 0,
                                total: 0
                            },
                            userGrowth: {
                                data: [0, 0, 0, 0, 0, 0],
                                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
                            },
                            engagement: {
                                dates: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                                activeUsers: [0, 0, 0, 0, 0, 0],
                                sessionDuration: [0, 0, 0, 0, 0, 0],
                                averageSession: 0,
                                sessionTrend: 0,
                                bounceRate: 0,
                                bounceTrend: 0,
                                retention: 0,
                                retentionTrend: 0
                            }
                        }
                    },
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                };

                products = [...products, newProduct];
                return newProduct;
            } catch (error) {
                reportError(error);
                throw error;
            }
        },

        updateProduct: async (productId, productData) => {
            try {
                await simulateNetworkDelay();
                
                const index = products.findIndex(p => p.objectId === productId);
                if (index === -1) {
                    throw new Error(`Product with ID ${productId} not found`);
                }

                const updatedProduct = {
                    ...products[index],
                    objectData: {
                        ...products[index].objectData,
                        ...productData
                    },
                    updatedAt: new Date().toISOString()
                };

                products[index] = updatedProduct;
                return updatedProduct;
            } catch (error) {
                reportError(error);
                throw error;
            }
        },

        deleteProduct: async (productId) => {
            try {
                await simulateNetworkDelay();
                
                const index = products.findIndex(p => p.objectId === productId);
                if (index === -1) {
                    throw new Error(`Product with ID ${productId} not found`);
                }

                products = products.filter(p => p.objectId !== productId);
                return { success: true };
            } catch (error) {
                reportError(error);
                throw error;
            }
        }
    };
}
