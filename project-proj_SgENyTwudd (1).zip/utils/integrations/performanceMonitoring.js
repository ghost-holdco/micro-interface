async function PerformanceMonitoringAPI(config) {
    // Lighthouse performance metrics
    async function getLighthouseMetrics(url) {
        try {
            const response = await fetch(`https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=${url}`, {
                headers: {
                    'Authorization': `Bearer ${config.googleApiKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Web Vitals metrics
    async function getWebVitalsMetrics(siteId) {
        try {
            const response = await fetch(`https://api.webvitals.io/v1/sites/${siteId}/metrics`, {
                headers: {
                    'Authorization': `Bearer ${config.webVitalsKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // SpeedCurve performance monitoring
    async function getSpeedCurveMetrics(siteId) {
        try {
            const response = await fetch(`https://api.speedcurve.com/v1/sites/${siteId}`, {
                headers: {
                    'Authorization': `Bearer ${config.speedCurveKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Calibre performance monitoring
    async function getCalibreMetrics(siteId) {
        try {
            const response = await fetch(`https://api.calibreapp.com/sites/${siteId}/metrics`, {
                headers: {
                    'Authorization': `Bearer ${config.calibreKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        getLighthouseMetrics,
        getWebVitalsMetrics,
        getSpeedCurveMetrics,
        getCalibreMetrics
    };
}
