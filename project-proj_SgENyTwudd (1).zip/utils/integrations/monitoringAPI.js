async function MonitoringAPI(product) {
    // Datadog API integration
    async function getDatadogMetrics(apiKey, appId) {
        try {
            const response = await fetch('https://api.datadoghq.com/api/v1/metrics', {
                headers: {
                    'DD-API-KEY': apiKey,
                    'DD-APPLICATION-KEY': appId
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // New Relic API integration
    async function getNewRelicMetrics(apiKey, accountId) {
        try {
            const response = await fetch(`https://api.newrelic.com/v2/applications/${accountId}/metrics.json`, {
                headers: {
                    'X-Api-Key': apiKey
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Cloudflare API integration
    async function getCloudflareMetrics(apiKey, zoneId) {
        try {
            const response = await fetch(`https://api.cloudflare.com/client/v4/zones/${zoneId}/analytics/dashboard`, {
                headers: {
                    'Authorization': `Bearer ${apiKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Uptime Robot API integration
    async function getUptimeMetrics(apiKey) {
        try {
            const response = await fetch('https://api.uptimerobot.com/v2/getMonitors', {
                method: 'POST',
                headers: {
                    'content-type': 'application/json',
                },
                body: JSON.stringify({
                    'api_key': apiKey,
                    'format': 'json',
                    'logs': 1
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Pingdom API integration
    async function getPingdomMetrics(apiKey, checkId) {
        try {
            const response = await fetch(`https://api.pingdom.com/api/3.1/checks/${checkId}`, {
                headers: {
                    'Authorization': `Bearer ${apiKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // StatusCake API integration
    async function getStatusCakeMetrics(apiKey, testId) {
        try {
            const response = await fetch(`https://api.statuscake.com/v1/uptime/${testId}`, {
                headers: {
                    'Authorization': apiKey
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Better Stack (Uptime) API integration
    async function getBetterStackMetrics(apiKey) {
        try {
            const response = await fetch('https://uptime.betterstack.com/api/v2/monitors', {
                headers: {
                    'Authorization': `Bearer ${apiKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        getDatadogMetrics,
        getNewRelicMetrics,
        getCloudflareMetrics,
        getUptimeMetrics,
        getPingdomMetrics,
        getStatusCakeMetrics,
        getBetterStackMetrics
    };
}
