async function GitHubAPI(repoOwner, repoName, token) {
    const BASE_URL = 'https://api.github.com';

    async function fetchWithAuth(endpoint) {
        try {
            const response = await fetch(`${BASE_URL}${endpoint}`, {
                headers: {
                    'Authorization': `token ${token}`,
                    'Accept': 'application/vnd.github.v3+json'
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getRepoDetails() {
        try {
            return await fetchWithAuth(`/repos/${repoOwner}/${repoName}`);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getCommitActivity() {
        try {
            return await fetchWithAuth(`/repos/${repoOwner}/${repoName}/stats/commit_activity`);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getIssues() {
        try {
            return await fetchWithAuth(`/repos/${repoOwner}/${repoName}/issues`);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getPullRequests() {
        try {
            return await fetchWithAuth(`/repos/${repoOwner}/${repoName}/pulls`);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        getRepoDetails,
        getCommitActivity,
        getIssues,
        getPullRequests
    };
}
