async function VercelAPI(projectId, token) {
    const BASE_URL = 'https://api.vercel.com';

    async function fetchWithAuth(endpoint) {
        try {
            const response = await fetch(`${BASE_URL}${endpoint}`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getDeployments() {
        try {
            return await fetchWithAuth(`/v6/deployments?projectId=${projectId}`);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getProjectMetrics() {
        try {
            return await fetchWithAuth(`/v6/projects/${projectId}/metrics`);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getEnvironmentVariables() {
        try {
            return await fetchWithAuth(`/v6/projects/${projectId}/env`);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        getDeployments,
        getProjectMetrics,
        getEnvironmentVariables
    };
}
