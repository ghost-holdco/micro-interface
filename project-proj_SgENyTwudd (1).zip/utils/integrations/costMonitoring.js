async function CostMonitoringAPI(config) {
    // AWS Cost Explorer
    async function getAWSCosts() {
        try {
            const response = await fetch(`https://ce.${config.region}.amazonaws.com/costs`, {
                headers: {
                    'Authorization': `AWS4-HMAC-SHA256 ${config.awsCredentials}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Stripe usage and costs
    async function getStripeCosts() {
        try {
            const response = await fetch('https://api.stripe.com/v1/balance/history', {
                headers: {
                    'Authorization': `Bearer ${config.stripeKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Digital Ocean costs
    async function getDigitalOceanCosts() {
        try {
            const response = await fetch('https://api.digitalocean.com/v2/customers/my/billing_history', {
                headers: {
                    'Authorization': `Bearer ${config.doToken}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Cloudflare usage and costs
    async function getCloudflareCosts(zoneId) {
        try {
            const response = await fetch(`https://api.cloudflare.com/client/v4/zones/${zoneId}/analytics/billing`, {
                headers: {
                    'Authorization': `Bearer ${config.cloudflareToken}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        getAWSCosts,
        getStripeCosts,
        getDigitalOceanCosts,
        getCloudflareCosts
    };
}
