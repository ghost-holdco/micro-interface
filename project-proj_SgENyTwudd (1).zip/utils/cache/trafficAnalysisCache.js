async function TrafficAnalysisCache() {
    const trickleObjAPI = new TrickleObjectAPI();
    const CACHE_OBJECT_TYPE = 'traffic-analysis-cache';
    const CACHE_DURATION = 30 * 60 * 1000; // 30 minutes in milliseconds

    async function getCachedAnalysis(domain) {
        try {
            const cacheKey = `${domain}-traffic`;
            const cachedData = await trickleObjAPI.listObjects(
                CACHE_OBJECT_TYPE,
                1,
                true,
                undefined
            );

            if (cachedData.items.length > 0) {
                const cache = cachedData.items[0];
                const now = new Date().getTime();
                const cacheTime = new Date(cache.createdAt).getTime();

                // Check if cache is still valid
                if (now - cacheTime < CACHE_DURATION) {
                    return cache.objectData.analysisData;
                }

                // Cache expired, delete it
                await trickleObjAPI.deleteObject(CACHE_OBJECT_TYPE, cache.objectId);
            }

            return null;
        } catch (error) {
            reportError(error);
            return null;
        }
    }

    async function setCachedAnalysis(domain, analysisData) {
        try {
            // Delete any existing cache for this domain
            const existingCache = await trickleObjAPI.listObjects(
                CACHE_OBJECT_TYPE,
                1,
                true,
                undefined
            );

            if (existingCache.items.length > 0) {
                await trickleObjAPI.deleteObject(
                    CACHE_OBJECT_TYPE,
                    existingCache.items[0].objectId
                );
            }

            // Create new cache entry
            await trickleObjAPI.createObject(CACHE_OBJECT_TYPE, {
                domain,
                analysisData,
                createdAt: new Date().toISOString()
            });
        } catch (error) {
            reportError(error);
        }
    }

    async function clearCache(domain) {
        try {
            const cachedData = await trickleObjAPI.listObjects(
                CACHE_OBJECT_TYPE,
                100,
                true,
                undefined
            );

            for (const cache of cachedData.items) {
                if (!domain || cache.objectData.domain === domain) {
                    await trickleObjAPI.deleteObject(CACHE_OBJECT_TYPE, cache.objectId);
                }
            }
        } catch (error) {
            reportError(error);
        }
    }

    async function getCacheStats() {
        try {
            const cachedData = await trickleObjAPI.listObjects(
                CACHE_OBJECT_TYPE,
                100,
                true,
                undefined
            );

            return {
                totalEntries: cachedData.items.length,
                domains: cachedData.items.map(cache => cache.objectData.domain),
                oldestEntry: cachedData.items.length > 0 
                    ? cachedData.items[cachedData.items.length - 1].createdAt 
                    : null,
                newestEntry: cachedData.items.length > 0 
                    ? cachedData.items[0].createdAt 
                    : null
            };
        } catch (error) {
            reportError(error);
            return {
                totalEntries: 0,
                domains: [],
                oldestEntry: null,
                newestEntry: null
            };
        }
    }

    return {
        getCachedAnalysis,
        setCachedAnalysis,
        clearCache,
        getCacheStats
    };
}
