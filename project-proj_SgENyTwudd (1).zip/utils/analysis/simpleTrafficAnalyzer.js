async function SimpleTrafficAnalyzer(domain, ahrefsApiKey) {
    // Base configuration
    const config = {
        timeout: 30000,
        retries: 3,
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    };

    async function analyzeTraffic() {
        try {
            const [
                ahrefsData,
                performanceData,
                socialData
            ] = await Promise.all([
                getAhrefsMetrics(),
                getPerformanceMetrics(),
                getSocialMetrics()
            ]);

            return {
                traffic: ahrefsData,
                performance: performanceData,
                social: socialData,
                lastUpdated: new Date().toISOString()
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Get traffic data from Ahrefs
    async function getAhrefsMetrics() {
        try {
            const response = await fetch(`https://api.ahrefs.com/v1/site-explorer/overview?target=${domain}&mode=domain&limit=5`, {
                headers: {
                    'Authorization': `Bearer ${ahrefsApiKey}`,
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            const data = await response.json();
            return {
                organicTraffic: data.metrics.organic_traffic,
                paidTraffic: data.metrics.paid_traffic,
                backlinks: data.metrics.backlinks,
                referringDomains: data.metrics.referring_domains,
                organicKeywords: data.metrics.organic_keywords,
                trafficValue: data.metrics.traffic_value,
                topCountries: data.metrics.top_countries,
                trafficSources: {
                    organic: Math.round((data.metrics.organic_traffic / (data.metrics.organic_traffic + data.metrics.paid_traffic)) * 100),
                    paid: Math.round((data.metrics.paid_traffic / (data.metrics.organic_traffic + data.metrics.paid_traffic)) * 100),
                    direct: 0, // Estimated
                    social: 0  // Estimated
                }
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Get performance metrics using PageSpeed Insights (free)
    async function getPerformanceMetrics() {
        try {
            const response = await fetch(`https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=https://${domain}&strategy=mobile`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            const data = await response.json();
            return {
                performance: Math.round(data.lighthouseResult.categories.performance.score * 100),
                firstContentfulPaint: data.lighthouseResult.audits['first-contentful-paint'].displayValue,
                speedIndex: data.lighthouseResult.audits['speed-index'].displayValue,
                largestContentfulPaint: data.lighthouseResult.audits['largest-contentful-paint'].displayValue,
                timeToInteractive: data.lighthouseResult.audits['interactive'].displayValue,
                totalBlockingTime: data.lighthouseResult.audits['total-blocking-time'].displayValue
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Get basic social metrics using free APIs
    async function getSocialMetrics() {
        try {
            // Using a combination of meta tags and public APIs
            const [facebookData, twitterData] = await Promise.all([
                getFacebookShares(),
                getTwitterShares()
            ]);

            return {
                facebook: facebookData,
                twitter: twitterData
            };
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    // Get Facebook shares using their public API
    async function getFacebookShares() {
        try {
            const response = await fetch(`https://graph.facebook.com/v12.0/?id=https://${domain}&fields=engagement&access_token=public`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            const data = await response.json();
            return {
                shares: data.engagement?.share_count || 0,
                reactions: data.engagement?.reaction_count || 0,
                comments: data.engagement?.comment_count || 0
            };
        } catch (error) {
            reportError(error);
            return { shares: 0, reactions: 0, comments: 0 };
        }
    }

    // Get Twitter shares using their public API
    async function getTwitterShares() {
        try {
            const response = await fetch(`https://cdn.syndication.twimg.com/widgets/followbutton/info.json?screen_names=${domain}`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}. description: ${await response.text()}`);
            }

            const data = await response.json();
            return {
                followers: data[0]?.followers_count || 0
            };
        } catch (error) {
            reportError(error);
            return { followers: 0 };
        }
    }

    return {
        analyzeTraffic
    };
}
