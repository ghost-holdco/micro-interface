function TechStackAPI() {
    const trickleObjAPI = new TrickleObjectAPI();
    const TECH_OBJECT_TYPE = 'technology';

    async function addTechnology(techData) {
        try {
            return await trickleObjAPI.createObject(TECH_OBJECT_TYPE, techData);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getTechnologies() {
        try {
            const response = await trickleObjAPI.listObjects(TECH_OBJECT_TYPE, 100, true);
            return response.items;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function updateTechnology(techId, techData) {
        try {
            return await trickleObjAPI.updateObject(TECH_OBJECT_TYPE, techId, techData);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function deleteTechnology(techId) {
        try {
            await trickleObjAPI.deleteObject(TECH_OBJECT_TYPE, techId);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        addTechnology,
        getTechnologies,
        updateTechnology,
        deleteTechnology
    };
}
