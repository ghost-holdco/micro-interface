function ProductAPI() {
    const trickleObjAPI = new TrickleObjectAPI();
    const PRODUCT_OBJECT_TYPE = 'saas-product';

    async function addProduct(productData) {
        try {
            return await trickleObjAPI.createObject(PRODUCT_OBJECT_TYPE, productData);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function getProducts() {
        try {
            const response = await trickleObjAPI.listObjects(PRODUCT_OBJECT_TYPE, 100, true);
            return response.items;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function updateProduct(productId, productData) {
        try {
            return await trickleObjAPI.updateObject(PRODUCT_OBJECT_TYPE, productId, productData);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    async function deleteProduct(productId) {
        try {
            await trickleObjAPI.deleteObject(PRODUCT_OBJECT_TYPE, productId);
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        addProduct,
        getProducts,
        updateProduct,
        deleteProduct
    };
}
