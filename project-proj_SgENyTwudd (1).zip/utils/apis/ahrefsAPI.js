function AhrefsAPI(apiKey) {
    const BASE_URL = 'https://api.ahrefs.com/v1';

    async function fetchWithAuth(endpoint) {
        try {
            const response = await fetch(`${BASE_URL}${endpoint}`, {
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Accept': 'application/json'
                }
            });
            
            if (!response.ok) {
                // First try to get the error message from the response
                let errorMessage;
                try {
                    const errorData = await response.text();
                    errorMessage = `HTTP error! status: ${response.status}. description: ${errorData}`;
                } catch (e) {
                    errorMessage = `HTTP error! status: ${response.status}`;
                }
                throw new Error(errorMessage);
            }
            
            return await response.json();
        } catch (error) {
            reportError(error);
            console.log('Falling back to mock data due to API error:', error);
            return null;
        }
    }

    async function getDomainMetrics(domain) {
        try {
            const data = await fetchWithAuth(`/site-explorer/overview?target=${domain}&mode=domain&limit=5`);
            
            // If API call failed, use mock data
            if (!data) {
                return {
                    metrics: mockDomainData[domain]?.traffic || mockAnalysisData.traffic,
                    overview: mockDomainData[domain]?.social || mockAnalysisData.social
                };
            }

            // If API call succeeded, format the data
            return {
                metrics: {
                    organic_traffic: data.metrics?.organic_traffic || 0,
                    paid_traffic: data.metrics?.paid_traffic || 0,
                    backlinks: data.metrics?.backlinks || 0,
                    referring_domains: data.metrics?.referring_domains || 0,
                    organic_keywords: data.metrics?.organic_keywords || 0,
                    traffic_value: data.metrics?.traffic_value || 0
                },
                overview: {
                    facebook_shares: data.overview?.facebook_shares || 0,
                    facebook_reactions: data.overview?.facebook_reactions || 0,
                    facebook_comments: data.overview?.facebook_comments || 0,
                    twitter_followers: data.overview?.twitter_followers || 0
                }
            };
        } catch (error) {
            reportError(error);
            // Fallback to mock data on error
            return {
                metrics: mockDomainData[domain]?.traffic || mockAnalysisData.traffic,
                overview: mockDomainData[domain]?.social || mockAnalysisData.social
            };
        }
    }

    return {
        getDomainMetrics
    };
}
