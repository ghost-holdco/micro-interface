function DNSHealthAPI() {
    async function checkDNSHealth(domain) {
        try {
            // For development, return mock data
            return mockDomainData[domain]?.dns || mockAnalysisData.dns;
        } catch (error) {
            reportError(error);
            throw error;
        }
    }

    return {
        checkDNSHealth
    };
}
