function SSLAPI() {
    const BASE_URL = 'https://api.ssllabs.com/api/v3';

    async function analyzeHostSSL(hostname) {
        try {
            const response = await fetch(`${BASE_URL}/analyze?host=${hostname}&all=done`);
            
            if (!response.ok) {
                let errorMessage;
                try {
                    const errorData = await response.text();
                    errorMessage = `HTTP error! status: ${response.status}. description: ${errorData}`;
                } catch (e) {
                    errorMessage = `HTTP error! status: ${response.status}`;
                }
                throw new Error(errorMessage);
            }

            const data = await response.json();

            // Format API response
            return {
                grade: data.endpoints[0].grade || 'Unknown',
                hasWarnings: data.hasWarnings || false,
                isExceptional: data.endpoints[0].grade === 'A+',
                details: {
                    cert: {
                        subject: data.certs[0].subject || 'Unknown',
                        issuer: data.certs[0].issuerLabel || 'Unknown',
                        validFrom: data.certs[0].notBefore || 'Unknown',
                        validTo: data.certs[0].notAfter || 'Unknown',
                        validDays: Math.round((new Date(data.certs[0].notAfter) - new Date()) / (1000 * 60 * 60 * 24))
                    }
                }
            };
        } catch (error) {
            reportError(error);
            console.log('Falling back to mock data due to SSL API error:', error);
            
            // Return mock data on error
            return mockDomainData[hostname]?.ssl || mockAnalysisData.ssl;
        }
    }

    return {
        analyzeHostSSL
    };
}
