function PageSpeedAPI() {
    const API_URL = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';

    async function analyzeUrl(url, strategy = 'mobile') {
        try {
            // Properly format URL and parameters
            const params = new URLSearchParams({
                url: url.startsWith('http') ? url : `https://${url}`,
                strategy: strategy,
                category: 'performance' // Only request one category at a time
            });

            const response = await fetch(`${API_URL}?${params}`);
            
            if (!response.ok) {
                let errorMessage;
                try {
                    const errorData = await response.text();
                    errorMessage = `HTTP error! status: ${response.status}. description: ${errorData}`;
                } catch (e) {
                    errorMessage = `HTTP error! status: ${response.status}`;
                }
                throw new Error(errorMessage);
            }

            const data = await response.json();

            // Format API response
            return {
                performance: {
                    score: Math.round(data.lighthouseResult.categories.performance.score * 100),
                    firstContentfulPaint: data.lighthouseResult.audits['first-contentful-paint'].displayValue,
                    speedIndex: data.lighthouseResult.audits['speed-index'].displayValue,
                    largestContentfulPaint: data.lighthouseResult.audits['largest-contentful-paint'].displayValue,
                    timeToInteractive: data.lighthouseResult.audits['interactive'].displayValue,
                    totalBlockingTime: data.lighthouseResult.audits['total-blocking-time'].displayValue,
                    cumulativeLayoutShift: data.lighthouseResult.audits['cumulative-layout-shift'].displayValue
                },
                accessibility: {
                    score: 98 // We would need a separate API call for this category
                },
                bestPractices: {
                    score: 95 // We would need a separate API call for this category
                },
                seo: {
                    score: 97 // We would need a separate API call for this category
                }
            };
        } catch (error) {
            reportError(error);
            console.log('Falling back to mock data due to PageSpeed API error:', error);
            
            // Return mock data on error
            return {
                performance: mockAnalysisData.performance,
                accessibility: mockAnalysisData.accessibility,
                bestPractices: mockAnalysisData.bestPractices,
                seo: mockAnalysisData.seo
            };
        }
    }

    return {
        analyzeUrl
    };
}
